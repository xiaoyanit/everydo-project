try:
  from Products.CMFPlone.Portal import addPolicy
  from Products.CMFPlone.CustomizationPolicy import DefaultCustomizationPolicy

  ##########################
  # Chinese Policy
  ##########################
  class ZopeChinaDefaultCustomizationPolicy(DefaultCustomizationPolicy):
    """ policy for Chinese Plone Site """

    def customize(self, portal):
        DefaultCustomizationPolicy.customize(self, portal)
        mi_tool = portal.portal_migration
        zcps = mi_tool._getWidget('ZopeChinaPak Setup')
        zcps.addItems(zcps.available())

  addPolicy('Default Chinese Plone', ZopeChinaDefaultCustomizationPolicy())
except ImportError:
  pass

##########################
# use Pinyin for id
##########################
from pinyin import PinYinDict
try:
    from Products.CMFPlone import UnicodeNormalizer

    UnicodeNormalizer.mapping.update(PinYinDict)
except ImportError:
    pass

try: 
    from plone.i18n.normalizer import base

    base.mapping.update(PinYinDict)
except ImportError:
    pass

del PinYinDict

####################
# make plone 2.1 can support chinese
#####################
from Products.CMFPlone import PloneTool
import re

PloneTool.BAD_CHARS = re.compile(r'[^a-zA-Z0-9-_~,.$\(\)# ]%').findall

