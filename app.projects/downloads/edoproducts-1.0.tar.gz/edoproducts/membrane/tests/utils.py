def sortTuple(t):
    l = list(t)
    l.sort()
    return tuple(l)
