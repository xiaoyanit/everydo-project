"""
CJKSplitter - Chinese, Japanese, Korean word splitter for ZCTextIndex

(C) by www.ZopeChina.com, panjy@zopechina.com & others

License: see LICENSE.txt

$Id: Exp $
"""

from CJKSplitter import CJKSplitter

def initialize(context):
  pass
