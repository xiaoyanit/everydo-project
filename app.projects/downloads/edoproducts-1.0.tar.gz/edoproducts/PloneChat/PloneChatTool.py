# -*- coding: utf-8 -*-
## PloneChat
## Copyright (C)2005 Ingeniweb

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; see the file COPYING. If not, write to the
## Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
"""
  PloneChat tool
"""
__docformat__ = 'restructuredtext'

# zope3
from zope.interface import implements

# Zope imports
from Globals import InitializeClass
from AccessControl import ClassSecurityInfo
from OFS.SimpleItem import SimpleItem
from OFS.PropertyManager import PropertyManager
from Products.PageTemplates.PageTemplateFile import PageTemplateFile

# CMF imports
from Products.CMFCore.utils import UniqueObject, getToolByName
from Products.CMFCore import permissions

# Product imports
from Products.PloneChat.config import *
from Products.PloneChat.PloneChatFileStorage import PloneChatFileStorage
from Products.PloneChat.PloneChatSqlStorage import PloneChatSqlStorage
from interface import IPloneChatTool

def SQLConnectionIDs(self):
    """
        Find SQL database connections in the current folder and above
        This function return a list of ids.
    """
    ids={}
    have_id=ids.has_key
    StringType=type('')

    while self is not None:
        if hasattr(self, 'objectValues'):
            for o in self.objectValues():
                if (hasattr(o,'_isAnSQLConnection') and o._isAnSQLConnection
                    and hasattr(o,'id')):
                    id=o.id
                    if type(id) is not StringType: id=id()
                    if not have_id(id):
                        if hasattr(o,'title_and_id'): o=o.title_and_id()
                        else: o=id
                        ids[id]=id
        if hasattr(self, 'aq_parent'): self=self.aq_parent
        else: self=None

    ids=    map(lambda item: (item[1], item[0]), ids.items())
    ids.sort()
    return ids

def setConnectionId(obj, evt):
    obj.setSqlConnectorId()

class PloneChatTool(UniqueObject, SimpleItem):
    """ Tool for PloneChat """

    implements(IPloneChatTool)

    plone_tool = True
    id = 'portal_plone_chat'
    title = "Plonechat tool"
    meta_type = "PloneChatTool"
    
    manage_options = (
        {'label': 'Chat Properties',
         'action': 'manage_chat'},
    ) + SimpleItem.manage_options

    security = ClassSecurityInfo()

    manage_chat = PageTemplateFile('www/manage_Chat', globals())

    chat_storage = None
    sql_connector_id = ''
    
    # ####################
    # Storage support
    # ####################

    security.declareProtected(permissions.View, 'getMessages')
    def getMessages(self, moderated, chat):
        """ get messages from selected storage """
        return self.chat_storage.getMessages(moderated, chat)

    security.declareProtected(permissions.View, 'insertNewMessage')
    def insertNewMessage(self, messageToSend, chat):
        """ insert a new message in storage """
        #current_user = self.getCurrentMemberId()
        current_user_id = self.getCurrentMemberId()
        mtool = getToolByName(self, 'portal_membership') #benky
        current_user = mtool.getMemberInfo(current_user_id)['fullname'] or current_user_id #benky 
        if current_user == None and chat.getAllowAnonymous():
            current_user = self.getAnonymousUserId(chat.UID())        
        return self.chat_storage.insertNewMessage(messageToSend, current_user, chat)

    def generateAnonymousId(self, chat):
        """ Generate id for anonymous """
        # CHANGE: This can be slow for long chat sessions, used ids may need to be saved in other place
        chat_uid = chat.UID()
        max_id = 0
        used_ids = [entry['member'] for entry in self.getLogs(chat)]
        for i in used_ids:
            if i[0:4] == 'user':
                try:
                    max_id=max(int(i[4:]), max_id)
                except:
                    continue
        new_id = 'user'+str(max_id+1)

        self.REQUEST.RESPONSE.setCookie('chatid-'+chat_uid, new_id, expires='Wed, 19 Feb 2020 14:28:00 GMT')
        return new_id

    def getAnonymousUserId(self, chat_uid):
        """ get anonymous id """
        return self.REQUEST.get('chatid-'+chat_uid, None)

    def getCurrentMemberId(self):
        """ get user id from """
        return getToolByName(self, 'portal_membership').getAuthenticatedMember().getId()
    
    def isModerator(self):
        """ return moderation rights """
        return getToolByName(self, 'portal_membership').checkPermission('moderateMessages', self)

    security.declareProtected(PloneChat_moderatePermission, 'moderateMessages')
    def moderateMessages(self, messages, mode, chat):
        """
                remove messages from pending list and add them to messages list if mode is "accept"
                mode in ('accept', 'del')
        """
        return self.chat_storage.moderateMessages(messages, mode, chat)

    security.declareProtected(permissions.ManagePortal, 'clearLogs')
    def clearLogs(self, chat_uid):
        """
                remove all messages from storage, but not pending ones
        """
        return self.chat_storage.clearLogs(chat_uid)

    security.declareProtected(permissions.View, 'getLogs')
    def getLogs(self, chat):
        """
                Return all the moderated messages
        """
        return self.chat_storage.getLogs(chat)

    security.declareProtected(permissions.View, 'getUserList')    
    def getUserList(self):
        """
            Return user list from all chat
        """
        return self.aq_parent.objectValues()


    # ##############
    # Manage methods
    # ##############
    def setSqlConnectorId(self, sql_connector_id = '', REQUEST=None):
        """ """
        self.sql_connector_id = sql_connector_id
        if sql_connector_id:
            self.chat_storage = PloneChatSqlStorage(self, sql_connector_id)
        else:
            self.chat_storage = PloneChatFileStorage()

        if REQUEST is not None:
            return REQUEST.RESPONSE.redirect(
                self.absolute_url() + \
                '/manage_chat?manage_tabs_message=SQL+connector+id+updated',
            )
    def getSqlConnectorId():
        """ """
        return self.aq_parent.sql_connector_id

InitializeClass(PloneChatTool)
