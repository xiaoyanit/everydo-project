# -*- coding: utf-8 -*-
## PloneChat
## Copyright (C)2005 Ingeniweb

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; see the file COPYING. If not, write to the
## Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

from funittest import physical
from funittest import logical
from funittest import interpreter
from funittest import dataprovider
from funittest import register_pc
from funittest import Testable
import random
import os

class Chat(Testable):

    def existing_chat(self, chat, user=None):        
        interpreter.annotate("Setup chat")
        if logical.cmfplone.search.search_content(chat, "matches:0"):
            # Let admin add chat
            admin_user=dataprovider.cmfplone.user.get('sampleadmin')
            logical.cmfplone.application.change_user(admin_user)                  
            # When there is no search result, the add drop-down is not accessible
            logical.cmfplone.navigation.top()
            # If the chat can not be found, it should be added
            logical.cmfplone.folder.add(chat)
            logical.cmfplone.content.edit(chat)        
            logical.cmfplone.content.save(chat)
            # Change user to the one that should be logged in on the chat
            if user == None or user['id'] == 'sampleadmin':
                # Just go to the view, sampleadmin is already logged in
                physical.cmfplone.tab.access("view")
            else:
                # Log in as the user that should be on the chat
                logical.cmfplone.application.change_user(user)
                # Go directly to the chat using the search
                logical.cmfplone.search.search_content(chat)
                # Go to search result
                interpreter.clickAndWait("link=%s" % chat['title'])
        else:
            if user != None:
                print user
                # Login with the user that should be on the chat
                logical.cmfplone.application.change_user(user)
            # Go to search result
            interpreter.clickAndWait("link=%s" % chat['title'])
                
register_pc("PloneChat", Chat())
