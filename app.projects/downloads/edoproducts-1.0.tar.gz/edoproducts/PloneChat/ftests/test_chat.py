# -*- coding: utf-8 -*-
## PloneChat
## Copyright (C)2005 Ingeniweb

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; see the file COPYING. If not, write to the
## Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
import unittest
from funittest import logical
from funittest import dataprovider
from funittest import precondition
from funittest import interpreter
from funittest import TestCase

import os

class TestChat(TestCase):

    def setUp(self):    
        TestCase.setUp(self)
        interpreter.open("")        

    def test_anonymous_chat(self):
        "Anonymous chat"
        interpreter.annotate("Test: Anonymous chat")
        chat = dataprovider.plonechat.chat.get("Anonymous Chat")
        precondition.plonechat.chat.existing_chat(chat) 
        logical.plonechat.chat.send_message("Message 1")
        logical.plonechat.chat.send_message("Message 2") 
        
    def test_see_logs(self):
        interpreter.annotate("See the chat logs")
        chat = dataprovider.plonechat.chat.get("Anonymous Chat")
        user=dataprovider.cmfplone.user.get('sampleadmin')
        precondition.plonechat.chat.existing_chat(chat, user) 
        logical.plonechat.chat.send_message("Message 1")
        interpreter.click("seeLogs")
        interpreter.wait_for_pop_up("_blank",10000)
        os.system("pause")
        
    def test_see_logs_knowing_template_name(self):
        interpreter.annotate("See the chat logs knowing the template name")
        chat = dataprovider.plonechat.chat.get("Anonymous Chat")
        precondition.plonechat.chat.existing_chat(chat) 
        logical.plonechat.chat.send_message("Message 1")
        logical.plonechat.chat.send_message("Message 2") 
        interpreter.open('PloneChat_logs_view')
        self.failUnless("Message 1" in interpreter.get_text("message-log"))
        
    def test_clear_logs(self):
        chat = dataprovider.plonechat.chat.get("Anonymous Chat")
        user=dataprovider.cmfplone.user.get('sampleadmin')
        precondition.plonechat.chat.existing_chat(chat, user) 
        logical.plonechat.chat.send_message("Message 1")
        self.failUnless("Message 1" in interpreter.get_text("chat-window"))
        logical.plonechat.chat.clear_logs()
        interpreter.wait_for_condition("selenium.getText('chat-window')=='';",10000) 
        interpreter.open('PloneChat_logs_view')
        self.failIf("Message 1" in interpreter.get_text("message-log"))
        
if __name__ == "__main__":
    unittest.main()
