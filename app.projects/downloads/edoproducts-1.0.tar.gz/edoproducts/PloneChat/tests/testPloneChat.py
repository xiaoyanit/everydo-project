"""
PloneChat base test

$Id: testPloneChat.py 16553 2005-10-24 14:49:49Z roeder $
"""

from common import *

tests = []
class TestPloneChat(PloneChatTestCase):

    def testCreateChat(self, ):
        """
        """
        self.loginAsPortalMember()
        self.chat = self.createEmptyChat(self.member_folder)

    def testEditChat(self, ):
        """
        Editing chat
        """
        self.testCreateChat()
        title = "A dummy title"
        description = "A dummy description"
        
        # Edit content
        self.util_tool.contentEdit(self.chat,
                                     title = title,
                                     description = description)
        
        # test if everything is ok
        self.failUnless(self.chat.Title() == title, "Value is %s" % self.chat.Title())
        self.failUnless(self.chat.Description() == description, "Value is %s" % self.chat.Description())

    def testPostModerated(self,):
        """
        Post a question and test that it is available
        """
        # Create chat
        self.testCreateChat()
        
        # Switch Moderation on
        self.chat.manage_editPloneChat(moderation = 1)

        # Check pending questions emptyness
        self.failUnless(not self.chat.listPendingQuestions())
        
        # Post a question
        self.chat.postModerated("WAZUP", "user1")
        self.failUnless(len(self.chat.listPendingQuestions()) == 1,)
        self.failUnless(self.chat.listPendingQuestions()[0]['question'] == 'WAZUP')

    def testModerateQuestion(self,):
        """
        Test a question moderation rejecting
        """
        # Create chat
        self.testCreateChat()
        
        # Switch Moderation on
        self.chat.manage_editPloneChat(moderation = 1)
        
        # Post a question
        self.chat.postModerated("WAZUP", "user1")
        self.failUnless(len(self.chat.listPendingQuestions()) == 1,)
        self.failUnless(self.chat.listPendingQuestions()[0]['question'] == 'WAZUP')

        # Moderate it and check that moderation list is empty
        self.chat.ignoreQuestion(self.chat.listPendingQuestions()[0]['id'])
        self.failUnless(not self.chat.listPendingQuestions(), "Questions pending: " + str(self.chat.listPendingQuestions()))

        # Post another question
        self.chat.postModerated("WAZUP", "user1")
        self.failUnless(len(self.chat.listPendingQuestions()) == 1,"Questions pending: " + str(self.chat.listPendingQuestions()))
        self.failUnless(self.chat.listPendingQuestions()[0]['question'] == 'WAZUP', "Question: " + str(self.chat.listPendingQuestions()[0]))

        # Accept it and check that moderation list is empty
        self.chat.acceptQuestion(self.chat.listPendingQuestions()[0]['id'])
        self.failUnless(not self.chat.listPendingQuestions(), "Questions pending: " + str(self.chat.listPendingQuestions()))

    def testChat(self,):
        """
        Test a whole chat session
        """
        # Create chat
        self.testCreateChat()
        
        # Post a question
        self.chat.postModerated("WAZUP", "user1")
        self.failUnless(len(self.chat.listPendingQuestions()) == 1,)
        self.failUnless(self.chat.listPendingQuestions()[0]['question'] == 'WAZUP')

        # Accept it and check that it is now on the chat list
        self.chat.acceptQuestion(self.chat.listPendingQuestions()[0]['id'])
        self.failUnless(len(self.chat.getChat()) == 1, "The question is not in the chat or chat size is invalid. Length:" + str(len(self.chat.getChat())))
        self.failUnless(self.chat.getChat()[0]['user'] == 'user1', "Username for chat question is invalid")
        self.failUnless(self.chat.getChat()[0]['text'] == "WAZUP", "Question is invalid")

        # Now, chat a bit
        self.chat.postUnmoderated("TRUE", "user2")
        self.failUnless(len(self.chat.getChat()) == 2, "The answer has not been taken into consideration")
        self.failUnless(self.chat.getChat()[-1]['user'] == "user2", "Username for chat question is invalid")
        self.failUnless(self.chat.getChat()[-1]['text'] == "TRUE", "Chat post text is invalid")

    def testMultiline(self,):
        """
        Test multi-lines or empty posts
        """
        # Create chat
        self.testCreateChat()
        
        # Post a thing
        self.chat.postUnmoderated("WAZUP\n\nTRUE", "user1")
        self.failUnless(len(self.chat.getChat()) == 1,)

        # Post an empty thing
        self.chat.postUnmoderated("\n\n", "user1")                                      # We ignore empty strings
        self.failUnless(len(self.chat.getChat()) == 1,)

        # Post a BIG thing
        self.chat.postUnmoderated("""\n\n
        Bon, on essaie maintenant de tester avec du contenu o� l'on glisse incidieusement vers quelque chose
        de beaucoup plus sioux. Genre avec des accents, et tout, et tout.
        En plus, on a pris soin d'�taler la chose sur plusieurs lignes, avec des caract�res � afficher
        plut�t particuliers. Le but, ici, est de tester que �a ne pose pas de probl�mes de stockage.
        """, "user1")                                      # We ignore empty strings
        self.failUnless(len(self.chat.getChat()) == 2,)

tests.append(TestPloneChat)

if __name__ == '__main__':
    framework()
else:
    # While framework.py provides its own test_suite()
    # method the testrunner utility does not.
    import unittest
    def test_suite():
        suite = unittest.TestSuite()
        for test in tests:
            suite.addTest(unittest.makeSuite(test))
        return suite
