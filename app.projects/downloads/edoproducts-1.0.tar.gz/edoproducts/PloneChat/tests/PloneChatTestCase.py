"""PloneChat tests

$Id: PloneChatTestCase.py 16553 2005-10-24 14:49:49Z roeder $
"""

__author__ = ''
__docformat__ = 'restructuredtext'

# Python imports
import time

# Zope imports
from Testing import ZopeTestCase
from AccessControl.SecurityManagement import newSecurityManager
from AccessControl.SecurityManagement import noSecurityManager
from Acquisition import aq_base

# CMF imports
from Products.CMFCore import CMFCorePermissions
from Products.CMFCore.utils import getToolByName

# Plone imports
from Products.CMFPlone.tests import PloneTestCase

# Products imports
from Products.PloneChat.Extensions.Install import install as installPloneChat

portal_name = PloneTestCase.portal_name
portal_owner = PloneTestCase.portal_owner
portal_member = 'portal_member'

class PloneChatTestCase(PloneTestCase.PloneTestCase):
    """ PloneChat test case based on a plone site"""

    def afterSetUp(self):
        # Tools shortcuts
        self.type_tool = getToolByName(self.portal, 'portal_types')
        self.wf_tool = getToolByName(self.portal, 'portal_workflow')
        self.mb_tool = getToolByName(self.portal, 'portal_membership')
        self.util_tool = getToolByName(self.portal, 'plone_utils')
        self.member_folder = self.mb_tool.getHomeFolder(portal_member)
    
    def createEmptyChat(self, container, content_id = 'chat'):
        # return empty chat
        container.invokeFactory(type_name='PloneChat', id=content_id)
        self.failUnless(content_id in container.objectIds())
        chat = getattr(container, content_id)
        self.assertEqual(chat.title, '')
        self.assertEqual(chat.getId(), content_id)
        return chat

    def createChat(self, container):
        #create empty chat
        self.chat = self.createEmptyChat(container)

    def beforeTearDown(self):
        # logout
        noSecurityManager()
    
    def loginAsPortalMember(self):
        '''Use if you need to manipulate an chat as member.'''
        uf = self.portal.acl_users
        user = uf.getUserById(portal_member).__of__(uf)
        newSecurityManager(None, user)
        
    def loginAsPortalOwner(self):
        '''Use if you need to manipulate an chat as member.'''
        uf = self.app.acl_users
        user = uf.getUserById(portal_owner).__of__(uf)
        newSecurityManager(None, user)

def setupPloneChat(app, quiet=0):
    get_transaction().begin()
    _start = time.time()
    portal = app.portal
    
    if not quiet: ZopeTestCase._print('Installing PloneChat ... ')

    # login as manager
    user = app.acl_users.getUserById(portal_owner).__of__(app.acl_users)
    newSecurityManager(None, user)
    
    # add PloneChat
    try:
        installPloneChat(portal)
    except:
        ZopeTestCase._print('PloneChat already installed ... ')
    
    # Create portal member
    portal.portal_registration.addMember(portal_member, 'azerty', ['Member'])
    
    # Log out
    noSecurityManager()
    get_transaction().commit()
    if not quiet: ZopeTestCase._print('done (%.3fs)\n' % (time.time()-_start,))

app = ZopeTestCase.app()
setupPloneChat(app)
ZopeTestCase.close(app)
