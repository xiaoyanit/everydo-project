# -*- coding: utf-8 -*-
## PloneChat
## Copyright (C)2005 Ingeniweb

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; see the file COPYING. If not, write to the
## Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
"""
"""
__version__ = "$Revision: 18811 $"
# $Source: /cvsroot/ingeniweb/PloneChat/Attic/PloneChatFileStorage.py,v $
# $Id: PloneChatFileStorage.py 18811 2006-02-01 11:22:08 +0100 (mer., 01 févr. 2006) cbosse $
__docformat__ = 'restructuredtext'

# Python imports
import random, string, os.path
import time

# Zope imports
from AccessControl import ClassSecurityInfo
from DateTime import DateTime

# CMF imports
from Products.CMFCore.utils import getToolByName
from Products.CMFCore import permissions

# Product imports
from Products.PloneChat.config import *
from Products.PloneChat.interfaces.PloneChat import IPloneChatStorage

class PloneChatFileStorage:
    """PloneChat class for file storage"""

    __implements__ = (IPloneChatStorage,)
 
    security = ClassSecurityInfo()

    # ###############
    # Interface
    # ###############
    security.declareProtected(permissions.ManagePortal, 'clearLogs')
    def clearLogs(self, chat_uid):
        """
        remove all moderated messages
        chat_uid --> uid of PloneChat object.
        """
        csv_file = file(self.getFilePath(chat_uid=chat_uid), 'w')
        csv_file.write('')
        csv_file.close()
        log_file = file(self.getFilePath(log=True, chat_uid=chat_uid), 'w')
        log_file.write('')
        log_file.close()

        return True

    security.declareProtected(PloneChat_moderatePermission, 'moderateMessages')
    def moderateMessages(self, messages, mode, chat):
        """
        Remove messages from pending storage
        add it to moderated messages storage if mode == 'accept'
        messages: list of dict
        mode --> accept / del
        chat --> PloneChat object
        """
        # get chat field values
        chat_uid = chat.UID()
        date_format = chat.getChatDateFormat()
        max_size = chat.getMaxMessageNumber()
        # get file
        csv_file_path = self.getFilePath(log=False, moderated=False, chat_uid=chat_uid)
        csv_file = file(csv_file_path, 'r')
        messages_in_file = csv_file.readlines()
        csv_file.close()
        result_list = []
        # for each selected messages
        for m in messages:
            # check if id is in messages list
            for message in messages_in_file:
                message_id = message.split(';;')[0]
                # if yes, add to result list and remove it from messages list
                if message_id == m['id']:
                    result_list.append((message, m))
                    messages_in_file.remove(message)
                    break
        csv_file = file(csv_file_path, 'w')
        csv_file.write(''.join(messages_in_file))
        csv_file.close()

        # add the new message to log_file and csv_file
        if mode == 'accept':
            date = DateTime().strftime(date_format)
            new_lines = []
            for old_item, new_message in result_list:
                tmp = old_item.split(';;', 3)
                #id, member_name, date, message
                new_line = '%s;;%s;;%s;;%s\n' % (tmp[0], tmp[1], date, new_message['content'].strip())
                new_lines.append(new_line)
            self.csvInsertMessagesWithoutModeration(new_lines, chat_uid, max_size)
        return True

    security.declareProtected(permissions.View, 'getMessages') 
    def getMessages(self, moderated, chat):
        """
        Return all messages in a html string
        moderated --> True / False
        chat --> PloneChat object.
        This methods must return a list of items like this:
        items --> list of mappings {'date' : 'date in chatDateFormat',
                                    'id'   : 'message id',
                                    'member' : 'username',
                                    'message' : 'message text'}                                                                                        
        """
        # get chat field values
        chat_uid = chat.UID()

        # get file
        if moderated:
            csv_file = file(self.getFilePath(chat_uid=chat_uid), 'r')
        else:
            csv_file = file(self.getFilePath(log=False, moderated=False, chat_uid=chat_uid), 'r')
        message_list = csv_file.readlines()

        new_list = []
        for item in message_list:
            tmp = item.split(';;', 3)
            new_list.append({'id' : tmp[0],
                             'date' : tmp[2],
                             'member' : tmp[1],
                             'message' : tmp[3].strip()})
        return new_list
    
    security.declareProtected(permissions.View, 'insertNewMessage')
    def insertNewMessage(self, messageToSend, member_name, chat):
        """
        add a new message to log file
        push a new message inside "last messages" file
        messageTosend --> message sent by client browser
        member_name --> current member id
        chat --> PloneChat object
        """
        # get chat field values
        chat_uid = chat.UID()
        max_size = chat.getMaxMessageNumber()
        date_format = chat.getChatDateFormat()
        
        if not chat.canPost():
            return True

        if messageToSend:
            moderation = False        
            if not chat.canChat():
                moderation = True

            # get message data    
            date = DateTime()
            id=''.join([random.choice(string.letters)+random.choice(string.digits) for x in range(0,15)])
            new_line = '%s;;%s;;%s;;%s\n' % (id, member_name, date.strftime(date_format), messageToSend.strip()) 
            # update only unmoderated csv file
            if moderation:
                csv_file = file(self.getFilePath(log=0, moderated=False, chat_uid=chat_uid), 'ab')
                csv_file.write(new_line)
                csv_file.close()
            # update log file and csv file  if moderated
            else:
                self.csvInsertMessagesWithoutModeration([new_line,], chat_uid, max_size)
                    
        return True

    security.declareProtected('View', 'getLogs')
    def getLogs(self, chat):
        """
        Return all the moderated messages
        This methods must return a list of items like this:
        items --> list of mappings {'date' : 'date in chatDateFormat',
                                    'id'   : 'message id',
                                    'member' : 'username',
                                    'message' : 'message text'}                                                                                        
        """
        chat_uid = chat.UID()
        csv_file = file(self.getFilePath(log=True, chat_uid=chat_uid), 'r')
        message_list = csv_file.readlines()

        new_list = []
        for item in message_list:
            tmp = item.split(';;', 3)
            new_list.append({'id' : tmp[0],
                             'date' : tmp[2],
                             'member' : tmp[1],
                             'message' : tmp[3].strip()})
        return new_list

    # #############
    # utils
    # #############
    
    security.declarePrivate("getFilePath")
    def getFilePath(self, chat_uid, log=False, moderated=True):
        """ Return log file or csv file path """
        base_file_id = 'chat_%s' % chat_uid
        j = os.path.join
        file_path = j(VAR_DIR, base_file_id)
        if log:
            file_path += '.log'
        else:
            if moderated:
                file_path += '.csv'
            else:
                file_path += '_pending.csv'
        # first time, will create an empty file
        if not os.path.exists(file_path):
            new_file = file(file_path, 'w')
            new_file.close()
        return file_path

    security.declarePrivate('pushItem')
    def pushItem(self, mylist, item):
        """
        add a new item at the end of mylist and remove the first item
        """
        if mylist:
            mylist = mylist[1:]
        mylist.append(item)
        return mylist

    security.declarePrivate('csvInsertMessageWithoutModeration')
    def csvInsertMessagesWithoutModeration(self, new_lines, chat_uid, max_size):
        """
        Insert a new message in log_file and csv_file
        new_line is a string to insert inside the file
        """
        result_str = ''
        for new_line in new_lines:
            result_str += new_line
            
        # update log file
        log_file = file(self.getFilePath(chat_uid, log=1), 'ab')
        log_file.write(result_str)
        log_file.close()
        # read csv file and get data
        csv_file_path = self.getFilePath(chat_uid)
        csv_file = file(csv_file_path, 'rb')
        messages = csv_file.readlines()
        csv_file.close()
        # push new message into csv file
        csv_file = file(csv_file_path, 'wb')
        len_messages = len(messages)
        if len_messages == max_size:
            for new_line in new_lines:
                messages = self.pushItem(messages, new_line)
        elif len_messages > max_size:
            messages = messages[:max_size]
            for new_line in new_lines:
                messages = self.pushItem(messages, new_line)
        else:
            messages.append(result_str)
        csv_file.write(''.join(messages))
        csv_file.close()
        return True
