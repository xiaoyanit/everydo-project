# -*- coding: utf-8 -*-
## PloneChat
## Copyright (C)2005 Ingeniweb

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; see the file COPYING. If not, write to the
## Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
"""
"""
__version__ = "$Revision: 18811 $"
# $Source: /cvsroot/ingeniweb/PloneChat/interfaces/Attic/PloneChat.py,v $
# $Id: PloneChat.py 18811 2006-02-01 11:22:08 +0100 (mer., 01 févr. 2006) cbosse $
__docformat__ = 'restructuredtext'

from Interface import Interface

class IPloneChatStorage(Interface):
    """
    Interface for PloneChat object
    """
    def clearLogs(self, chat_uid):
        """
        remove all moderated messages
        chat_uid --> PloneChat object uid.
        """

    def getMessages(self, moderated, chat):
        """
        Return all messages in a html string
        moderated --> True / False
        chat --> PloneChat object.
        This methods must return a list of items like this:
        items --> list of mappings {'date' : 'date in chatDateFormat',
                                    'id'   : 'message id',
                                    'member' : 'username',
                                    'message' : 'message text'}
        """

    def moderateMessages(self, messages, mode, chat):
        """
        Remove message from pending storage
        add it to moderated messages storage if mode == 'accept'
        messages --> list of {'id': int, 'content': string}
        mode --> accept / del
        chat --> PloneChat object
        """

    def insertNewMessage(self, messageToSend, member_name, chat):
        """
        add a new message to moderated or unmoderated messages list
        messageTosend --> message sent by client browser
        member_name --> current member id
        chat --> PloneChat object
        """

    def getLogs(self, chat):
        """
        Return all the moderated messages
        This methods must return a list of items like this:
        items --> list of mappings {'date' : 'date in chatDateFormat',
                                    'id'   : 'message id',
                                    'member' : 'username',
                                    'message' : 'message text'}
        """
