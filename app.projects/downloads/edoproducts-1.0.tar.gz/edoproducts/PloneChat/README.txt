ABOUT

 This product is chat (interactive discussion tool) product for Zope/CMF/Plone.

DEPENDENCIES

 * Zope 2.7
  
 * Plone 2.0.5+
  
 * Archetypes 1.3.3
  
  
INSTALL
 
 * Untar it inside your Zope "Products" directory

 * Install the product on your plone site with quickinstaller


OVERVIEW
	
 * View tab : 
 
  Will allow you to discuss with other people connected in the chat room.
    
 * Moderation Tab: 
 
  Will allow the moderator to accept or edit users messages.
  To edit a message just double click on it, a text area will be show. 
  Changes will be done on validation.
  IMPORTANT : If your chat is set with moderation, 'defaut' users won't
  be able to discuss with other and will have to wait until a moderator
  review their message.
        
 * Members: 
 
  Will allow you to choose who's going to moderate users.
    	
 * PloneChat Tool: 
 
  You can change the storage method between a text file (csv) 
  and a database that you've already set up. (Check Storage section 
  for better info)
    	
 * Portlet :
 
  It will allow you to see members connected in any chat rooms anywhere
  in your plone site.
  You can put a portlet in your Plone Site properties 
  by adding 'here/portlet_chat_users/macros/portlet' in left or right slot
    
        
STORAGE

 * How to define the storage for your PloneChat ?

   For now, 2 storages are available : "sql", "csv".
   
   Once Product PloneChat is installed in a plone instance, it creates a tool
   named "portal_plone_chat". In the "Chat properties" tabs, there is a field
   named "plonechat_sql_conn". If you leave it empty, the CSV file storage will
   be used. Else, the string has to be a valid SQL Connector id.
   The PloneChatTool will create an instance of your chat storage.

 * CSV Storage

   "csv" is the default storage, and will store all messages inside
    files in "$INSTANCE_HOME/var/Plonechat" in 3 files :

      * "chat_${chat_uid}.csv" : will store the last moderated messages (see the
        "maxMessageNumber" field to define the max size for this file);

      * "chat_${chat_uid}_pending.csv" : will store all unmoderated messages;

      * "chat_${chat_uid}.log" : will store all moderated messages;

 * SQL Storage
 
  The connector must have a connection to a database with a table named
  "plonechat_logs". The table is created upon storage creation, your sql
  connector must have the right to create a table.

 * IPloneChatStorage interface

  All storages modules must implements this interface. So it will be
  easy to add new storage possibilities.

  see "/interfaces/PloneChat.py" for more informations
 
PLONECHAT PERF

 You can define on PloneChat object these fields:

 * the "refresh rate": a low refresh rate will increase the CPU load. A good refresh rate is 5 seconds;
      
 * the "max message number": define how many messages you want to
        display inside the chat window. Higher is this value, slower
        is the chat. A good value for this field is 50. User could at
        any time see all the logs if necessary;
        
 * the "only update": It will only get messages you still have not retrieved.
      		Might not be really usefull with cache.
        
PloneChat and cache

 caching the url "mychaturl/getModeratedMessages" will really
 increase the perfs for high traffic chats. Set the caching refresh rate
 to 5 seconds will send to zope 1 request every 5 seconds, when
 cache will send to users hundreds request.

 If you are using the cache, you will be able to set the refresh rate
 to 2 seconds.

 PloneChat and RAMCache
  
 For now, PloneChat can not use RAMCache, see "TO DO" section below.

PLONECHAT AND ZEO

 If you are using zeo, you have to use the "sql" storage.

SECURITY
  
   Moderation is based on Zope's roles, according to the following schema:

  - 'Member' role gives user the permission to chat moderatedly

  - 'Owner' role gives user the ability to chat unmoderatedly

  - 'Reviewer' role gives user the ability to moderate a chat.

 This is hard-coded but very easy to change. An interface similar
 to Plone's folder_localrole_form is provided so that it's easy to change roles.

 **IMPORTANT :** It's impossible for the chat creator to assign the Reviewer role to himself.
 We changed this, however, to give a Reviewer local role at object instanciating, to give
 the possiblity for the object creator to be Moderator as well.


DATE FORMAT

 When you use the SQL backend, the date format is as follow:
  
 - **%a** 	Abbreviated weekday name (Sun..Sat)
    
 - **%b** 	Abbreviated month name (Jan..Dec)
    
 - **%c** 	Month, numeric (0..12)
    
 - **%D** 	Day of the month with English suffix (0th, 1st, 2nd, 3rd, ...)
   
 - **%d** 	Day of the month, numeric (00..31)
    
 - **%e** 	Day of the month, numeric (0..31)
    
 - **%f** 	Microseconds (000000..999999)
    
 - **%H** 	Hour (00..23)
    
 - **%h** 	Hour (01..12)
    
 - **%I** 	Hour (01..12)
    
 - **%i** 	Minutes, numeric (00..59)
    
 - **%j** 	Day of year (001..366)
    
 - **%k** 	Hour (0..23)
    
 - **%l** 	Hour (1..12)
    
 - **%M** 	Month name (January..December)
    
 - **%m** 	Month, numeric (00..12)
    
 - **%p** 	AM or PM
    
 - **%r** 	Time, 12-hour (hh:mm:ss followed by AM or PM)
    
 - **%S** 	Seconds (00..59)
    
 - **%s** 	Seconds (00..59)
    
 - **%T** 	Time, 24-hour (hh:mm:ss)
    
 - **%U** 	Week (00..53), where Sunday is the first day of the week
    
 - **%u** 	Week (00..53), where Monday is the first day of the week
    
 - **%V** 	Week (01..53), where Sunday is the first day of the week; used with **%X**
    
 - **%v** 	Week (01..53), where Monday is the first day of the week; used with **%x**
    
 - **%W** 	Weekday name (Sunday..Saturday)
    
 - **%w** 	Day of the week (0=Sunday..6=Saturday)
    
 - **%X** 	Year for the week where Sunday is the first day of the week, numeric, four digits; used with **%V**
    
 - **%x** 	Year for the week, where Monday is the first day of the week, numeric, four digits; used with **%v**
    
 - **%Y** 	Year, numeric, four digits
    
 - **%y** 	Year, numeric, two digits
    
 - **%%** 	A literal %.
    

TO DO

 * Add the possibility to cache getModeratedMessages in RAMCache -->
 create a py script;

 * add the possibility for admin to limit the chat users number;

KNOWN BUGS

 * Opera browser does not support PloneChat for now;

 * Encoding problems on konqueror and IE;


