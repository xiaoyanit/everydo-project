# -*- coding: utf-8 -*-
## PloneChat
## Copyright (C)2005 Ingeniweb

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; see the file COPYING. If not, write to the
## Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
"""
"""
__version__ = "$Revision: 18811 $"
# $Source: /cvsroot/ingeniweb/PloneChat/Attic/PloneChatSqlStorage.py,v $
# $Id: PloneChatSqlStorage.py 18811 2006-02-01 11:22:08 +0100 (mer., 01 févr. 2006) cbosse $
__docformat__ = 'restructuredtext'

import datetime

# Zope imports
import Acquisition
import Globals
from AccessControl import ClassSecurityInfo
from Interface import Interface

# Products imports
from Products.ZSQLMethods.SQL import SQL

from Products.PloneChat.interfaces.PloneChat import IPloneChatStorage

DEFAULT_SQL_CONNECTOR_ID = 'plonechat_sql'

class PloneChatSqlMethods(Globals.Persistent, Acquisition.Implicit):
    """Class containing all sql methods"""

    def __init__(self, sql_connector_id):
        """ """
        #Create table
        create_table_query = ()
        
        self.createTables = SQL('createTables', 'Create Plone Chat Tables',
            sql_connector_id, '',
            """
            CREATE TABLE IF NOT EXISTS `plonechat_logs` (
                `id`                INT UNSIGNED         NOT NULL AUTO_INCREMENT ,
                `chat_uid`        VARCHAR( 255 )         NOT NULL,
                `moderated`        INT( 1 ) UNSIGNED     NOT NULL,
                `date`            DATETIME             NOT NULL,
                `member_name`    VARCHAR( 255 )         NOT NULL ,
                `message`        TEXT                 NOT NULL,
            PRIMARY KEY (`id` ),
            INDEX ( `chat_uid` ),
            INDEX ( `moderated` )
            );
            """)

        self.clearLogs = SQL('clearLogs', 'Clear logs of a chat',
            sql_connector_id, 'chat_uid',
            """
            DELETE FROM     `plonechat_logs`
            WHERE        chat_uid = <dtml-sqlvar chat_uid type="string">;
                """)

        self.getMessages = SQL('getMessages', 'get messages of a chat',
            sql_connector_id, 'chat_uid moderated',
            """
            SELECT        id, date, member_name AS member, message
            FROM         `plonechat_logs`
            WHERE         chat_uid = <dtml-sqlvar chat_uid type="string">
            AND             moderated = <dtml-sqlvar moderated type="int">
            ORDER BY     `date` DESC
            """)

        self.acceptMessages = SQL('acceptMessages', 'accept list of messages',
            sql_connector_id, 'messages_ids',
             """
            UPDATE    `plonechat_logs`
            SET        moderated = 1
            WHERE
                <dtml-in messages_ids prefix=id>
                    <dtml-unless id_start>OR</dtml-unless>
                    id = <dtml-sqlvar id_item type="int">
                    </dtml-in>;
            """)


        self.editMessage = SQL('editMessage', 'edit a message',
            sql_connector_id, 'message_id content', 
            """
            UPDATE `plonechat_logs`
            SET         message = <dtml-sqlvar content type="string">
            WHERE
                    id         = <dtml-sqlvar message_id type="int">;
            """)

        self.deleteMessages = SQL('deleteMessages', 'delete list of messages',
            sql_connector_id, 'messages_ids',
            """
            DELETE FROM `plonechat_logs`
               WHERE
                <dtml-in messages_ids prefix=id>
                    <dtml-unless id_start>OR</dtml-unless>
                    id = <dtml-sqlvar id_item type="int">
                </dtml-in>;
            """)            

        self.insertMessage = SQL('insertMessage', 'insert a new message',
            sql_connector_id, 'chat_uid member_name message moderated',
            """
            INSERT INTO `plonechat_logs` (
                `chat_uid`, `moderated`, `date`, `member_name`, `message` )
            VALUES (
                <dtml-sqlvar chat_uid type="string">,
                <dtml-sqlvar moderated type="int">,
                NOW(),
                <dtml-sqlvar member_name type="string">,
                <dtml-sqlvar message type="string"> 
            );
            """)

        self.getLogs = SQL('getLogsQuery', 'return moderated messages',
            sql_connector_id, 'chat_uid',
            """
            SELECT 
                    id, date, member_name AS member, message
                FROM `plonechat_logs`
            WHERE
                chat_uid = <dtml-sqlvar chat_uid type="string">
                   AND moderated = 1
            ORDER BY `date` DESC
            """)            
        
class PloneChatSqlStorage(Globals.Persistent, Acquisition.Implicit):
    """
    PloneChat SQL storage
    """

    __implements__ = (IPloneChatStorage,)
    security = ClassSecurityInfo()
    _message_names = ('date', 'id', 'member', 'message')

    def __init__(self, chat_tool, sql_connector_id = DEFAULT_SQL_CONNECTOR_ID):
        self.sql_methods = PloneChatSqlMethods(sql_connector_id)
        self.sql_methods.__of__(chat_tool).createTables()
    
    def clearLogs(self, chat_uid):
        """
        remove all moderated messages
        chat_uid --> PloneChat object uid.
        """        
        self.sql_methods.clearLogs(chat_uid=chat_uid)
        return True

    def getMessages(self, moderated, chat):
        """
        Return all messages in a html string
        moderated --> True / False
        chat --> PloneChat object.
        This methods must return a list of items like this:
        items --> list of mappings {'date' : 'date in chatDateFormat',
                                    'id'   : 'message id',
                                    'member' : 'username',
                                    'message' : 'message text'}
        """
        chat_uid = chat.UID()
        moderated = int(moderated)
        date_format = chat.getChatDateFormat()
        max_msgs = chat.getMaxMessageNumber()
        results = self.sql_methods.getMessages(chat_uid=chat_uid,
                                               moderated=moderated,
                                               date_format=date_format,
                                               max_msgs=max_msgs)
        if results:
            results = self.dictFromSql(results, names=self._message_names)
            results = results[:max_msgs]
            for d in results:
                d['date'] = d['date'].strftime(date_format)
            results.reverse()
            return results
        else:
            return ()
        
    def moderateMessages(self, messages, mode, chat):
        """
        Remove message from pending storage
        add it to moderated messages storage if mode == 'accept'
        selected_ids --> list of message ids selected
        mode --> accept / del
        chat --> PloneChat object
        """
        messages_ids = []
        for m in messages:
            try:
                messages_ids.append(int(m['id']))
            except:
                pass

        if mode == 'accept':
            self.sql_methods.acceptMessages(messages_ids=messages_ids)
            for m in messages:
                self.sql_methods.editMessage(message_id=int(m['id']),
                                             content=m['content'].strip())
        else:
            self.sql_methods.deleteMessages(messages_ids=messages_ids)
                
    def insertNewMessage(self, messageToSend, member_name, chat):
        """
        add a new message to moderated or unmoderated messages list
        messageTosend --> message sent by client browser
        member_name --> current member id
        chat --> PloneChat object
        """
        chat_uid = chat.UID()
        moderated = chat.canChat()
        self.sql_methods.insertMessage(chat_uid=chat_uid,
                                       member_name=member_name,
                                       message=messageToSend,
                                       moderated=moderated)

        return True

    def getLogs(self, chat):
        """
        Return all the moderated messages
        This methods must return a list of items like this:
        items --> list of mappings {'date' : 'date in chatDateFormat',
                                    'id'   : 'message id',
                                    'member' : 'username',
                                    'message' : 'message text'}
        """
        chat_uid = chat.UID()
        date_format = chat.getChatDateFormat()        
        max_msgs = chat.getMaxMessageNumber()
        results = self.sql_methods.getLogs(chat_uid=chat_uid,
                                           max_msgs=max_msgs,
                                           date_format=date_format)
        if results:
            results = self.dictFromSql(results, names=self._message_names)
            results = results[:max_msgs]
            for d in results:
                d['date'] = d['date'].strftime(date_format)
            results.reverse()
            return results
        else:
            return ()


    def dictFromSql(self, results=(), names=()):
        """
        Convert a list of SQL rows to a list of dictionnaries
        """
        rows = []
        for sql_row in results:
            mapping = {}
            for col_name in names:
                mapping[col_name] = sql_row[col_name]
            rows.append(mapping)
        return rows
