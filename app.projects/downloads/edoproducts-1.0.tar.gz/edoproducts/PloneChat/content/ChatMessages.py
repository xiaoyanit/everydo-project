# -*- coding: utf-8 -*-
## PloneChat
## Copyright (C)2005 Ingeniweb

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; see the file COPYING. If not, write to the
## Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
"""
    Manages messages sent by users
"""
__docformat__ = 'restructuredtext'

import time

# Zope imports
from AccessControl import ClassSecurityInfo
from DateTime import DateTime

# CMF Imports
from Products.CMFCore import permissions
from Products.CMFCore.utils import getToolByName

from Products.PloneChat.config import TOOL_ID

class ChatMessages:
    "Chat Messages Tool class"
    security = ClassSecurityInfo()

    security.declarePrivate('formatResponse')
    def formatResponse(self, moderated, items):
        """
        items --> list of mappings {'date' : 'date in chatDateFormat',
                                    'id'   : 'message id',
                                    'member' : 'username',
                                    'message' : 'message text'}
        """
        now = DateTime()
        today = DateTime(now.year(), now.month(), now.day())

        tool = getToolByName(self, TOOL_ID)
        mtool = getToolByName(self, 'portal_membership')
        
        #userid = tool.getCurrentMemberId()        
        userid = tool.getCurrentMemberId()
        username = mtool.getMemberInfo(userid)['fullname'] or userid 
        
        if userid == None:
            userid = tool.getAnonymousUserId(self.UID())
        
        data = ''
        if self.displayWithTabs:
            data = '<chat moderation="%s">' % moderated
        data += self.getChatUsers() + '\t'
        if len(items) == 30:
            data += '<div><a target="_blank" href="PloneChat_logs_view">查看本次会话的全部记录...</a><div>'
        for item in items:            
            item['message'].replace("\x00", "")
            if self.displayWithTabs:
                data += '<msg author="%(member)s" id="%(id)s" date="%(date)s">%(message)s</msg>' % item
            else:
                item_time = DateTime(item['date'])
                item_date = DateTime(item_time.year(), item_time.month(), item_time.day())
                if item_date != today:
                    item_date_time = item['date']
                else:
                    item_date_time = item['date'].split(' ')[1]
                data += '<div id="%s"><label>%s</label>' % (item['id'], item_date_time,)
                if not moderated:
                    data += '<input type="checkbox" name="%s" />' % item['id']
                if item['member'] == username:
                    data += '<strong class="mine">%(member)s : </strong>%(message)s' % item
                else:
                    data += '<strong>%(member)s :</strong>%(message)s' % item
                data += '</div>'
        if self.displayWithTabs:
            data += '</chat>'
            self.REQUEST.RESPONSE.setHeader("Content-Type", "text/xml; charset=%s" % self.getCharset())
        self.REQUEST.RESPONSE.setHeader('Content-Length', len(data))
        return data

    ## cache methods
    #
    #  The caching policy is for reducing the number of request made to the
    #  backend. Thus, we may not do more than x request by second to ask for
    #  messages list. We do this by adjusting the expires time and never
    #  invalidating messages list upon message insertion / moderation
    
    __cache_expire_delay = 1 # 1s == 1 request by second
    
    def _getCachedMessages(self, moderated=True):
        cache_attr = moderated and '_v_moderated_messages' \
                     or '_v_unmoderated_messages'
        cache = getattr(self.aq_explicit, cache_attr, None)

        if cache == None:
            return None        

        if time.time() > cache['expires']:
            return None
        
        return cache['messages']

    def _setCachedMessages(self, messages, moderated=True):
        cache_attr = moderated and '_v_moderated_messages' \
                     or '_v_unmoderated_messages'
        cache = {'expires': time.time() + self.__cache_expire_delay,
                 'messages':  messages}
        setattr(self, cache_attr, cache)

    security.declarePrivate('getMessages')
    def getMessages(self, moderated=True, lastID=0):
        """ get messages """
        self.updateChatUsers()
        messages = self._getCachedMessages(moderated)
        if messages is None:
            tool = getToolByName(self, TOOL_ID)
            messages = tool.getMessages(moderated, self)
            try:
                index = map(lambda x:x['id'], messages).index(lastID)
                messages = messages[index + 1:]
            except:
                pass
            self._setCachedMessages(messages, moderated)
            
        lastID = len(messages) and messages[-1]['id'] or 0        
        return self.formatResponse(moderated, messages)

    security.declareProtected(permissions.View, 'insertNewMessage')
    def insertNewMessage(self, messageToSend=''):
        """
        insert a new message
        """
        self.updateChatUsers();
        tool = getToolByName(self, TOOL_ID)
        if messageToSend.startswith('[{sys}]'):
            messageToSend = messageToSend[7:]
        else:
          messageToSend = messageToSend \
            .replace('<', '&lt;').replace('>', '&gt;').replace('\n', '') \
            .replace('<br />', '').replace('<br>', '').replace('<br/>', '')
        tool.insertNewMessage(messageToSend, self)
    
    security.declareProtected(permissions.View, 'sendMessage')
    def sendMessage(self, fromUser, toUser, message):
        """ add a new message in storage """
        tool = getToolByName(self, TOOL_ID)
        return tool.chat_storage.insertNewMessage(message, fromUser, self) 
