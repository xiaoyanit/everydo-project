# -*- coding: utf-8 -*-
## PloneChat
## Copyright (C)2005 Ingeniweb

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; see the file COPYING. If not, write to the
## Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
"""
    Tracks users connecting to or leaving PloneChat
"""
__docformat__ = 'restructuredtext'

# Zope imports
from AccessControl import ClassSecurityInfo
from DateTime import DateTime

# CMF Imports
from Products.CMFCore import permissions
from Products.CMFCore.utils import getToolByName

from Products.PloneChat.config import TOOL_ID

chat_users = {}

class ChatUserTracker:
    "Chat User Tracker class"
    security = ClassSecurityInfo()

    def chat_users(self):
        uid = self.UID()
        return chat_users.setdefault(uid, {})
    
    security.declarePrivate('updateChatUsers')
    def updateChatUsers(self):
        """ update chat user list """
        tool = getToolByName(self, TOOL_ID)
        mtool = getToolByName(self, 'portal_membership')
        now = DateTime().timeTime()             
        for userid in self.chat_users().keys():
            date = self.chat_users()[userid]['date']
            # if user did not send any ping since refresh rate + 30 seconds,
            # remove it from the list
            if (date + self.getRefreshRate() + 60) < now:
                self.logoutUser(userid)
        #userid = tool.getCurrentMemberId()
        user_id = tool.getCurrentMemberId()
        userid = mtool.getMemberInfo(user_id)['fullname'] or user_id 

        if userid != None:
            if not self.chat_users().has_key(userid):
                self.chat_users()[userid] = { 'isModerator' : tool.isModerator(),
                                            'date' : now }
            else:
                self.chat_users()[userid]['date'] = now
        elif userid == None:
            userid = tool.getAnonymousUserId(self.UID())
            if userid == None:
                userid = tool.generateAnonymousId(self)
            self.chat_users()[userid] = { 'isModerator' : False,
                                        'date' : now }

    security.declareProtected(permissions.View, 'getChatUsers')
    def getChatUsers(self):
        """Return chat_users value"""
        keys = self.chat_users().keys()
        keys.sort()
        data = self.usersHTMLResponse(keys)
        return data
    
    security.declarePrivate('usersHTMLResponse')
    def usersHTMLResponse(self, keys):
        """ Format HTML response for ajax """
        data = ''
        for key in self.chat_users():
            item = self.chat_users()[key]
            className = ''
            if item['isModerator']:
               className = ' class="moderator"'
            data += '<div%s>%s</div>' % (className, key)
        return data
    
    security.declareProtected(permissions.View, 'logout')
    def logout(self):
        """ log out current chat user """
        userid = self.portal_plone_chat.getCurrentMemberId()
        if userid == None:
            tool = getToolByName(self, TOOL_ID)
            userid = tool.getAnonymousUserId(self.UID())
        return self.logoutUser(userid)    
    
    security.declarePrivate('logoutUser')
    def logoutUser(self, userid):
        """ remove user from the list and notice other chat users """
        if self.chat_users().has_key(userid):
            del self.chat_users()[userid]
            #self.sendMessage("[server]", "", "%s left the chat" % userid)    
            return True
        return False    
    
