# -*- coding: utf-8 -*-
## 
## Copyright (C)2005 Ingeniweb

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; see the file COPYING. If not, write to the
## Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
"""

"""
__docformat__ = 'restructuredtext'


# CMF imports
from Products.CMFCore import permissions

# Archetypes imports
from Products.Archetypes.public import *

PloneChatSchema = BaseSchema.copy() + Schema((
    IntegerField(
        'refreshRate',
        default        = 10,
        required        = True,
        widget        = IntegerWidget(
                label                = "Refresh rate",
                description            = "Enter the refresh rate of chat in seconds.",
                i18n_domain            = "plonechat",
                label_msgid            = "label_refresh_rate",
                description_msgid    = "help_refresh_rate"
        )
    ),
    IntegerField(
        'moderationRefreshRate',
        default        = 30,
        required        = True,
        widget        = IntegerWidget(
            label                = "Moderation refresh rate",
                description            = "Enter the refresh rate of moderation window in seconds.",
                i18n_domain            = "plonechat",
                label_msgid            = "label_moderation_refresh_rate",
                description_msgid    = "help_moderation_refresh_rate"
        )
    ),
    IntegerField(
        'maxMessageNumber',
        default        = 30,
        required        = True,
        widget        = IntegerWidget(
                label                = "Max message number",
                description            = "Maximum number of messages you want to display inside chat window",
                label_msgid            = "label_max_message_number",
                description_msgid    = "help_max_message_number",
                i18n_domain            = "plonechat"
        )
    ),
    StringField(
        'chatDateFormat',
        default        = '%Y/%m/%d %H:%M:%S',
        required        = True,
        widget        = StringWidget(
                label                = "Chat date format",
                description            = "Enter the date format visible in chat window.",
                i18n_domain            = "plonechat",
                label_msgid            = "label_chat_date_format",
                description_msgid    = "help_chat_date_format")
    ),
    BooleanField(
        'moderation',
        default        = False,
        widget        = BooleanWidget(
            label                =  "Moderation",
            description            =  "Check this box if you want to moderate this chat",
            i18n_domain            =  "plonechat",
            label_msgid            =  "label_moderation",
            description_msgid    =  "help_moderation"
        )
    ),
    BooleanField(
        'onlyUpdate',
        default        = False,
        widget        = BooleanWidget(
                label                =  "Only update",
                description            =  "Check this box if you only want new messages displayed",
                i18n_domain            =  "plonechat",
                label_msgid            =  "label_only_update",
                description_msgid    =  "help_only_update"
        )
    ),
    BooleanField(
        'displayWithTabs',
        default        = False,
        widget        = BooleanWidget(
                label                =  "Display with tabs",
                description            =  "Check this box if you want to use tabs display",
                i18n_domain            =  "plonechat",
                label_msgid            =  "label_display_with_tabs",
                description_msgid    =  "help_display_with_tabs"
        )
    ),
    StringField(
        'charset',
        default_method    = 'getDefaultPloneSiteCharset',
        widget            = StringWidget(visible    = {'edit' : 'invisible', 'view': 'invisible'})
    ),
    StringField(
        'messageColor',
        default        = 'blue',
        required        = True,
        widget        = StringWidget(
            label    = 'Message color',
                description    = 'Color for chat messages from other users',
                label_msgid    = 'label_message_color',
                description_msgid    = 'help_message_color',
                i18n_domain    = 'plonechat'
        )
    ),
    StringField(
        'myMessageColor',
        default        = 'red',
        required        = True,
        widget        = StringWidget(
            label    = 'My message color',
                description    = 'Color for my chat messages',
                label_msgid    = 'label_mymessage_color',
                description_msgid    = 'help_mymessage_color',
                i18n_domain    = 'plonechat'
        )
    ),
    IntegerField(
        'chatWindowHeight',
        required        = True,
        default        = 300,
        widget        = IntegerWidget(
                label    = 'Chat window heigth',
                description    = 'Give the chat window height in pixels',
                label_msgid    = 'label_chat_window_height',
                description_msgid    = 'help_chat_window_height',
                i18n_domain    = 'plonechat'
        )
    ),
    BooleanField(
        'allowAnonymous',
        default        = False,
        widget        = BooleanWidget(
                label                =  "Allow anonymous",
                description            =  "Check this box if you want to allow anonymous users to chat",
                i18n_domain            =  "plonechat",
                label_msgid            =  "label_allow_anonymous",
                description_msgid    =  "help_allow_anonymous"
        )
    ),    
))
