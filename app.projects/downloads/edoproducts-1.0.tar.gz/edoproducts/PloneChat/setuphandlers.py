# -*- encoding: UTF-8 -*-

"""
site setup handlers.
"""

from zope.component import getUtility
from zope.component import getMultiAdapter
from zope.component import queryUtility

from plone.portlets.interfaces import IPortletAssignmentMapping
from plone.portlets.interfaces import IPortletManager
from plone.portlets.interfaces import ILocalPortletAssignmentManager
from plone.portlets.constants import CONTEXT_CATEGORY as CONTEXT_PORTLETS
from plone.app.portlets import portlets

from Products.CMFFormController.interfaces import IFormControllerTool

# CMF imports
from Products.CMFCore.utils import getToolByName

# AT imports
from Products.Archetypes import listTypes
from Products.Archetypes.Extensions.utils import installTypes, install_subskin

# Product imports
from Products.PloneChat.config import *
from Products.PloneChat import PloneChatTool

def setPermissions(self):
    """
    setPermissions(self) => Set standard permissions / roles
    """
    # As a default behavior, newly-created permissions are granted to owner and manager.
    # To change this, just comment this code and grab back the code commented below to
    # make it suit your needs.
    for perm in PERMS_LIST:
        self.manage_permission(perm, ('Manager', 'Owner'), acquire=1)

    # Set special permissions
    self.manage_permission(PloneChat_restrictedChatPermission, ('Member', 'Manager', 'Owner', ), acquire=1)
    self.manage_permission(PloneChat_moderatePermission, ('Reviewer', 'Manager', ), acquire=1)

# import logging; warn = logging.getLogger('basecampsite').warn

def importContent(context):
    """
    Final Plone content import step.
    """
    site = context.getSite()

    # Install permissions
    setPermissions(site)
