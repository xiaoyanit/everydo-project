from zope.interface import Interface

class IPloneChat(Interface):
    pass

class IPloneChatTool(Interface):
    pass
