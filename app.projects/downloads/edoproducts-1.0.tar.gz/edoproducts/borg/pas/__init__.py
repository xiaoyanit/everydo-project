"""Pluggable Authentication Service plug-ins
"""