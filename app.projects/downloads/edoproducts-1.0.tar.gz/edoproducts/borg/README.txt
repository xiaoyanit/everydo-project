==========================
B-org : Base organisation
==========================

A generic implementation of membership and content structures relevant to organisations.
 
'b-org' is an infrastructure product. It provides scaffolding, but needs some dressing to actually be useful. It will provide three new content types:

Department -- A department represents information about an organisational department, but also acts as a group. A department is a folder, which can contain Employees. Contained employees are members of the group.

Employee -- An employee is represents information about an organisational employee, but is also a full user of the system.

Project -- A project is a folder for content relating to a project. Employees can be made managers or members of a project, giving them special permissions.

Departments acting as groups and Employees acting as users is achieved via
'membrane'. Local role management in Projects is achieved via a PAS plug-in.

In the spirit of 'membrane', user management is not based on the "Users and groups administration" control panel (although users defined there will continue to work unaffected). Instead, Departments, Employees and Projects are created in content space as part of the information architecture of the site.

'b-org' contains only the minimum of fields necessary to support this infrastructure. It makes no attempt at guessing what metadata departments, employees and users should have, nor how they should be displayed. This is left up to other, simpler products that can provide a fuller schema for the content objects. The DocTest 'EXTENDING.txt' covers this in more detail.

----------------
Acknowledgements
----------------

'b-org' is inspired by work by Plone Solutions (http://plonesolutions.com), sponsored by The Norwegian Consumer Council (http://forbrukerradet.no) - many thanks to them for providing the fundamental pattern and for sponsoring the development of 'membrane'.

Thanks to Wichert Akkerman for the original implementation of the PAS local role plug-in.

------------
Dependencies
------------

 o Zope 2.9+

 o Plone 2.5+

 o 'membrane':http://plone.org/products/membrane (use the development trunk, version 0.3 will not work)

------------
Installation
------------

'b-org' is set up using GenericSetup. To install it, go to 'portal_setup', and on the 'Properties' tab, select 'b-org' in the list of active profiles. Activate it, and then go to the 'Import' tab. Click 'import all steps'. You should now see 'Employee', 'Department' and 'Project' in 'portal_types', for example.
 
-----
Usage
-----

Typically, you will install 'b-org' using portal_setup as above, and then install a customisation product that changes the schemata, view templates and perhaps other aspects of the content types. Out-of-the-box, however, usage of 'b-org' is fairly simple.

Managers can create Departments anywhere in the portal. Only the bare minimum of meta-data is required. Note that id must be given, and must be unique - this is used as the id of the group that the department represents.

Departmental groups can also imply some portal-wide roles. For example, if the 'Member' role is selected for a department, any employee in that department will be given the member role globally (in contrast to Plone's member management functionality, the Member role is not given by default).

As soon as some employees have been created (see below), one or more employees may be set as a manager of a department. This means that this employee gets the Manager local role and will be able to add, modify and delete employees inside that department

A Department acts as a container for Employees, which may be added by a manager as regular content. Again, only the bare minimum of fields are provided. 

The title will act as the user's "full name" by default. Employees can also be given a list of roles above and beyond what their department (group) implies. A password must be set the first time the object is saved. On subsequent edits, the password will only be changed if it is set (thus the field is only mandatory on the first edit).

Note that once an Employee object is saved, it becomes a user. That user is then given ownership over its own Employee object. This is to ensure that employees can edit basic meta-data about themselves (fields such as user id and roles are only available to managers) and change their passwords. 

Employees start out in the Active state, but may be deactivated, at which point they cease to function as users (that is, they can no longer log in to the portal).

Projects can be created (by default only by managers) anywhere in the portal. Projects act as folders for content. When creating a content, any number of employees may be set as managers or members of the project (note that a manager is automatically also a member, so there is no need to select a user in both lists).

Projects become groups in the portal. Project team members and managers are members of this group. Note that these groups do not imply any global roles by default, but may be useful in managing users.

By default projects are visible to all. They can also be made private (visible only to team members) or archived (accepting no new content) via the 'state' menu.

Inside a project space, the default workflow (and also that of standard Folders) is altered. Content can be made visible (the default), private to the project's members, private to its owner, or published.

---
FAQ
---

Q: I'm getting an Attribute Error & the following traceback when adding an employee to a department:

Traceback (innermost last):
  Module ZPublisher.Publish, line 115, in publish
  Module ZPublisher.mapply, line 88, in mapply
  Module ZPublisher.Publish, line 41, in call_object
  Module Products.CMFPlone.FactoryTool, line 369, in __call__
  Module ZPublisher.mapply, line 88, in mapply
  Module ZPublisher.Publish, line 41, in call_object
  Module Products.CMFFormController.FSControllerPageTemplate, line 96, in __call__
  Module Products.CMFFormController.BaseControllerPageTemplate, line 39, in _call
  Module Products.CMFFormController.ControllerBase, line 243, in getNext
  Module Products.CMFFormController.Actions.TraverseTo, line 36, in __call__
  Module ZPublisher.mapply, line 88, in mapply
  Module ZPublisher.Publish, line 41, in call_object
  Module Products.CMFFormController.FSControllerPythonScript, line 107, in __call__
  Module Products.CMFFormController.Script, line 141, in __call__
  Module Products.CMFCore.FSPythonScript, line 108, in __call__
  Module Shared.DC.Scripts.Bindings, line 311, in __call__
  Module Shared.DC.Scripts.Bindings, line 348, in _bindAndExec
  Module Products.CMFCore.FSPythonScript, line 164, in _exec
  Module None, line 1, in content_edit
   - <FSControllerPythonScript at /borg/content_edit used for /borg/project-staff/portal_factory/Employee/employee.2006-09-21.0276881647>
   - Line 1
  Module Products.CMFCore.FSPythonScript, line 108, in __call__
  Module Shared.DC.Scripts.Bindings, line 311, in __call__
  Module Shared.DC.Scripts.Bindings, line 348, in _bindAndExec
  Module Products.CMFCore.FSPythonScript, line 164, in _exec
  Module None, line 11, in content_edit_impl
   - <FSPythonScript at /borg/content_edit_impl used for /borg/project-staff/portal_factory/Employee/employee.2006-09-21.0276881647>
   - Line 11
  Module Products.Archetypes.BaseObject, line 650, in processForm
  Module Products.borg.content.employee, line 123, in at_post_create_script
  Module zope.event, line 23, in notify
  Module zope.app.event.dispatching, line 66, in dispatch
  Module zope.component, line 181, in subscribers
  Module zope.component.site, line 89, in subscribers
  Module zope.interface.adapter, line 481, in subscribers
  Module Products.borg.events.employee, line 29, in modifyEmployeeOwnership
KeyError: 'User *yourusername* cannot be found.'

A: In this scenario, it's likely that you've created the Plone site choosing the "Base organisation" and "membrane" extension profiles and never set "b-org" as the active portal_setup profile and chosen "import all steps" from the import tab.  This is an admittedly confusing user interface.
