
def initialize(context):
    pass