from base import CharityTestCase

class TestSchema(CharityTestCase):

    def afterSetUp(self):
        self.setRoles(('Manager',))
        self.folder.invokeFactory('Department', 'dept')
        self.folder.dept.invokeFactory('Employee', 'emp')
        self.folder.invokeFactory('Project', 'proj')
        
        self.dept = self.folder.dept
        self.emp = self.dept.emp
        self.proj = self.folder.proj
        
    def test_department_schema_extended(self):
        field = self.dept.Schema()['description']
        self.failUnlessEqual(field.widget.label, u"Department description")
    
    def test_employee_schema_extended(self):
        field = self.emp.Schema()['email']
        self.failUnless(field)
    
    def test_project_schema_extended(self):
        field = self.proj.Schema()['background']
        self.failUnless(field)
        
def test_suite():
    from unittest import TestSuite, makeSuite
    suite = TestSuite()
    suite.addTest(makeSuite(TestSchema))
    return suite
