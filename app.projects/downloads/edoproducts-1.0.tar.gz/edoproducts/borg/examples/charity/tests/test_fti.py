from base import CharityTestCase

class TestFTI(CharityTestCase):

    def afterSetUp(self):
        self.types = self.portal.portal_types
        
    def test_department_fti_modified(self):
        fti = self.types['Department']
        self.assertEquals(fti.getMethodAliases()['(Default)'], '@@charity_department_view')
    
    def test_employee_fti_modified(self):
        fti = self.types['Employee']
        self.assertEquals(fti.getMethodAliases()['(Default)'], '@@charity_employee_view')
        
    def test_project_fti_modified(self):
        fti = self.types['Project']
        self.assertEquals(fti.getMethodAliases()['(Default)'], '@@charity_project_view')
        
def test_suite():
    from unittest import TestSuite, makeSuite
    suite = TestSuite()
    suite.addTest(makeSuite(TestFTI))
    return suite
