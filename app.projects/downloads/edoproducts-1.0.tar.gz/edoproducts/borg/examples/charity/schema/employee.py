from zope.interface import implements
from zope.component import adapts

from Products.Archetypes.atapi import *

from Products.borg.interfaces import IEmployeeContent
from Products.borg.interfaces import ISchemaExtender

CharityEmployeeSchema = Schema((
    
    StringField('title',
        accessor='Title',
        required=True,
        user_property='fullname',
        widget=StringWidget(
            label=u"Full name",
            description=u"Full name of this employee",
        ),
        
    ),
    
    StringField('email',
        validators=('isEmail',),
        required=True,
        searchable=True,
        user_property=True,
        widget=StringWidget(
            label=u"Email address",
            description=u"Enter the employee's email address",
        ),
    ),
    
    StringField('phone',
        required=False,
        searchable=True,
        user_property=True,
        widget=StringWidget(
            label=u"Phone number",
            description=u"Enter the employee's phone number",
        ),
    ),
    
    StringField('mobilePhone',
        required=False,
        searchable=True,
        user_property=True,
        widget=StringWidget(
            label=u"Mobile phone number",
            description=u"Enter the employee's mobile phone number",
        ),
    ),
    
    StringField('location',
        searchable=True,
        user_property=True,
        widget=StringWidget(
            label=u"Location",
            description=u"Your location - either city and country - or in a company setting, where your office is located.",
        ),
    ),
    
    StringField('language',
        user_property=True,
        vocabulary="availableLanguages",
        widget=SelectionWidget(
            label=u"Language",
            description=u"Your preferred language.",
        ),
    ),
    
    TextField('description',
        required=True,
        searchable=True,
        user_property=True,
        default_content_type='text/html',
        default_output_type = 'text/x-html-safe',
        allowable_content_types = ('text/html', 'text/structured', 'text/x-web-intelligent',),
        widget=RichWidget(
            label=u"Biography",
            description=u"Enter a short biography of the employee",
        ),
    ),
    
    ))

class EmployeeSchemaExtender(object):
    """Extend the schema of an employee to include additional fields.
    """
    implements(ISchemaExtender)
    adapts(IEmployeeContent)
    
    def __init__(self, context):
        self.context = context
    
    def extend(self, schema):
        schema = schema + CharityEmployeeSchema
        # Reorder some fields
        schema.moveField('description', after='mobilePhone')
        schema.moveField('location', before='description')
        schema.moveField('language', before='description')
        schema.moveField('roles_', after='description')
        return schema
