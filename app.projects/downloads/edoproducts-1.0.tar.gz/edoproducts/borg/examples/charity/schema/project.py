from zope.interface import implements
from zope.component import adapts

from Products.Archetypes.atapi import *

from Products.borg.interfaces import IProjectContent
from Products.borg.interfaces import ISchemaExtender

CharityProjectSchema = Schema((
    
    TextField('background',
        required=True,
        searchable=True,
        default_content_type='text/html',
        default_output_type = 'text/x-html-safe',
        allowable_content_types = ('text/html', 'text/structured', 'text/x-web-intelligent',),
        widget=RichWidget(
            label=u"Project background",
            description=u"Enter a description of the project",
        ),
    ),
    
    ))

class ProjectSchemaExtender(object):
    """Extend the schema of a project to include additional fields.
    """
    implements(ISchemaExtender)
    adapts(IProjectContent)
    
    def __init__(self, context):
        self.context = context
    
    def extend(self, schema):
        return schema + CharityProjectSchema