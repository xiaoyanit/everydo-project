from zope.interface import implements
from zope.component import adapts

from Products.Archetypes.atapi import *

from Products.borg.interfaces import IDepartmentContent
from Products.borg.interfaces import ISchemaExtender

CharityDepartmentSchema = Schema((
    
    TextField('description',
        user_property=True,
        required=True,
        searchable=True,
        default_content_type='text/html',
        default_output_type = 'text/x-html-safe',
        allowable_content_types = ('text/html', 'text/structured', 'text/x-web-intelligent',),
        widget=RichWidget(
            label=u"Department description",
            description=u"Enter a description of the department",
        ),
    ),
    
    ))

class DepartmentSchemaExtender(object):
    """Extend the schema of a project to include additional fields.
    """
    implements(ISchemaExtender)
    adapts(IDepartmentContent)
    
    def __init__(self, context):
        self.context = context
    
    def extend(self, schema):
        schema = schema + CharityDepartmentSchema
        # Make our title an official group properties
        schema['title'].user_property = True
        return schema
