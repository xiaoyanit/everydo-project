import logging
import os

from zope.component import queryMultiAdapter
from zope.interface import implements

from Products.GenericSetup.interfaces import IBody
from Products.GenericSetup.interfaces import ISetupEnviron
from Products.CMFCore.utils import getToolByName
from Products.DCWorkflow.DCWorkflow import DCWorkflowDefinition

class SetupEnviron(object):
    """Context for body im- and exporter.
    """

    implements(ISetupEnviron)

    def getLogger(self, name):
        return logging.getLogger('GenericSetup.%s' % name)

    def shouldPurge(self):
        return True

def updateFTI(context, productModule, ftiId):
    """Update the FTI with the given id from a GenericSetup definition file.
    
    The definition should live in 
    Products/{productModule}/Extensions/setup/types/${ftiId}.xml
    """
    
    
    typesTool = getToolByName(context, 'portal_types')
    obj = getattr(typesTool, ftiId)

    # create import context
    environ = SetupEnviron()

    # get XML body
    productPath = os.path.split(productModule.__file__)[0]
    definitionName = os.path.join(productPath, 'Extensions', 'setup', 'types', '%s.xml' % ftiId)
    f = file(definitionName)
    body = f.read()
    f.close()

    # apply XML body to adapted workflow and environ
    adapted = queryMultiAdapter((obj, environ), IBody)
    adapted.body = body