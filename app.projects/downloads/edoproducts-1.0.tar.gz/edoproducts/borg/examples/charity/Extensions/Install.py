from zope.event import notify

from Products.borg.content.employee import Employee
from Products.borg.content.schema import SchemaInvalidatedEvent

from Products import charity

from Products.charity.Extensions.utils import updateFTI

def install(self, reinstall=False):
    
    # Tell b-org that we are extending the employee schema
    
    # XXX: In Zope 2.10, we would like to register the adapter to 
    # ISchemaExtender as a *local* adapter here. Otherwise, the new
    # schema takes effect as soon as 'charity' is in the Products/ 
    # directory, rather than when it is installed.
    
    # At that point, we would also need to invalidate the schema as per below. 
    # Doing it now doesn't cause any harm, though.
    
    notify(SchemaInvalidatedEvent(Employee))
    
    # Modify the FTIs for Departments, Employees and Projects based on 
    # GenericSetup profile descriptors (note that we're not using the whole
    # GenericSetup mechanism here, only the configuration file handlers)
    
    # This will register the new actions and aliases for the charity views
    
    if not reinstall:
        updateFTI(self, charity, 'Department')
        updateFTI(self, charity, 'Employee')
        updateFTI(self, charity, 'Project')
    
def uninstall(self, reinstall=False):
    pass