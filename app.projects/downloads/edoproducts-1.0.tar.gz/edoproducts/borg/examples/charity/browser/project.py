from Products.Five.browser import BrowserView
from Products.borg.interfaces import IProject

class ProjectView(BrowserView):
    """A view of a charity project"""

    def __init__(self, context, request):
        self.context = context
        self.request = request
    
    def name(self):
        return self.context.Title()
        
    def managers(self):
        return self.context.getManagers()
        
    def members(self):
        return self.context.getMembers()
        
    def background(self):
        return self.context.getBackground()