from Products.Five.browser import BrowserView
from Products.borg.interfaces import IEmployee

class EmployeeView(BrowserView):
    """A view of a charity employee"""

    def __init__(self, context, request):
        self.context = context
        self.request = request

    def name(self):
        employee = IEmployee(self.context)
        return employee.fullname

    def email(self):
        return self.context.getEmail()

    def phone(self):
        return self.context.getPhone()

    def mobilePhone(self):
        return self.context.getMobilePhone()


    def homePhone(self):
        return self.context.getHomePhone()


    def biography(self):
        return self.context.Description()