from Products.Five.browser import BrowserView
from Products.borg.interfaces import IDepartment

class DepartmentView(BrowserView):
    """A view of a charity department"""

    def __init__(self, context, request):
        self.context = context
        self.request = request
    
    def name(self):
        return self.context.Title()
        
    def managers(self):
        return self.context.getManagers()
        
    def details(self):
        return self.context.Description()