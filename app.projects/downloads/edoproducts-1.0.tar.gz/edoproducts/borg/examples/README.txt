This directory contains examples of extensions to b-org.

Copy or symlink *one* example to your Products/ directory to see it in action.