from zope.interface import implements
from zope.component import adapts

from Products.membrane.interfaces import IUserRelated, IGroup

from Products.borg.interfaces import IProjectContent, IProject, IWorkspace, IEmployee
from Products.borg.config import PROJECT_RELATIONSHIP, PROJECT_MANAGER_RELATIONSHIP

class Project(object):
    """Provide project information.
    """
    implements(IProject)
    adapts(IProjectContent)

    def __init__(self, context):
        self.context = context

    @property
    def id(self):
        return self.context.getId()

    def getManagers(self):
        members = []
        for m in self.context.getManagers():
            employee = IEmployee(m, None)
            if employee is not None:
                members.append(employee)
        return members
    
    def getMembers(self):
        members = []
        for member in self.context.getRefs(PROJECT_RELATIONSHIP):
            employee = IEmployee(member, None)
            if employee is not None:
                members.append(employee)
        return members
        
class LocalRoles(object):
    """Provide a local role manager for projects
    """
    implements(IWorkspace)
    adapts(IProjectContent)

    def __init__(self, context):
        self.context=context

    def getLocalRoles(self):
        project = IProject(self.context)
        roles = {}
        for m in project.getManagers():
            roles[m.id] = ('Manager',)
        for m in project.getMembers():
            if m.id in roles:
                roles[m.id] += ('TeamMember',)
            else:
                roles[m.id] = ('TeamMember',)
        return roles

    def getLocalRolesForPrincipal(self, principal):
        principal_id = principal.getId()
        r = self.getLocalRoles()
        return r.get(principal_id, ())
        
class Group(object):
    """Allow projects to be groups for related members and managers
    """
    implements(IGroup)
    adapts(IProjectContent)

    def __init__(self, context):
        self.context = context

    def Title(self):
        return self.context.Title()
        
    def getRoles(self):
        # The project does not imply any special roles *globally*, although
        # the IWorkspace adapter above enables some local roles
        return ()
    
    def getGroupId(self):
        return self.context.getId()

    def getGroupMembers(self):
        return [IUserRelated(m).getUserId() for m in
                                 self.context.getRefs(PROJECT_RELATIONSHIP) +
                                 self.context.getRefs(PROJECT_MANAGER_RELATIONSHIP)]