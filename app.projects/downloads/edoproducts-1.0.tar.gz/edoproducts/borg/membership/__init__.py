"""Adapters for membrane integration
"""

import department
import employee
import project