from zope.interface import implements
from zope.component import adapts

from Products.CMFCore.utils import getToolByName

from Products.membrane.interfaces import IGroup
from Products.membrane.interfaces import IMembraneUserAuth
from Products.membrane.interfaces import ICategoryMapper

from Products.membrane.config import ACTIVE_STATUS_CATEGORY
from Products.membrane.config import TOOLNAME as MEMBRANE_TOOL
from Products.membrane.utils import generateCategorySetIdForType

from Products.borg.interfaces import IDepartment, IDepartmentContent
from Products.borg.interfaces import IEmployee, IEmployeeContent
from Products.borg.interfaces import IWorkspace

class Department(object):
    """Provide department information.
    """
    implements(IDepartment)
    adapts(IDepartmentContent)

    def __init__(self, context):
        self.context = context
        
    @property
    def id(self):
        return self.context.getId()

    def getManagers(self):
        managers = []
        for m in self.context.getManagers():
            manager = IEmployee(m, None)
            managers.append(manager)
        return managers

    def getEmployees(self):
        mt = getToolByName(self.context, MEMBRANE_TOOL)
        usr = mt.unrestrictedSearchResults
        employees = []
        for m in usr(object_implements=IEmployeeContent.__identifier__,
                     path='/'.join(self.context.getPhysicalPath())):
            employee = IEmployee(m.getObject(), None)
            if employee is not None:
                employees.append(employee)
        return employees

class LocalRoles(object):
    """Provide a local role manager for departments
    """
    implements(IWorkspace)
    adapts(IDepartmentContent)

    def __init__(self, context):
        self.context = context

    def getLocalRoles(self):
        project = IDepartment(self.context)
        roles = {}
        for m in project.getManagers():
            roles[m.id] = ('Manager',)
        return roles

    def getLocalRolesForPrincipal(self, principal):
        principal_id = principal.getId()
        r = self.getLocalRoles()
        return r.get(principal_id, ())
        
class Group(object):
    """Allow departments to act as groups for contained employees
    """
    implements(IGroup)
    adapts(IDepartmentContent)
    
    def __init__(self, context):
        self.context = context
        
    def Title(self):
        return self.context.Title()
    
    def getRoles(self):
        """Get roles for this department-group.
        
        Return an empty list of roles if the department is in a workflow state
        that is not active in membrane_tool.
        """
        mb = getToolByName(self.context, MEMBRANE_TOOL)
        wf = getToolByName(self.context, 'portal_workflow')
        
        reviewState = wf.getInfoFor(self.context, 'review_state')
        wfmapper = ICategoryMapper(mb)
        categories = generateCategorySetIdForType(self.context.portal_type)
        if wfmapper.isInCategory(categories, ACTIVE_STATUS_CATEGORY, reviewState):
            return self.context.getRoles()
        else:
            return ()
    
    def getGroupId(self):
        return self.context.getId()

    def getGroupMembers(self):
        mt = getToolByName(self.context, MEMBRANE_TOOL)
        usr = mt.unrestrictedSearchResults
        members = {}
        for m in usr(object_implements=IMembraneUserAuth.__identifier__,
                     path='/'.join(self.context.getPhysicalPath())):
            members[m.getUserId] = 1
        return tuple(members.keys())