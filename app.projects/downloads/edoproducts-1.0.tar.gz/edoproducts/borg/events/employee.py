from Acquisition import aq_parent, aq_inner

from Products.CMFCore.utils import getToolByName
from Products.membrane.interfaces import IUserRelated

def modifyEmployeeOwnership(event):
    """Let employees own their own objects.
    
    Stolen from Plone and CMF core, but made less picky about where users are 
    found.
    """
    context = event.context
    
    catalog = getToolByName(context, 'portal_catalog')
    
    userId = IUserRelated(context).getUserId()
    userFolder = getToolByName(context, 'acl_users')
    
    user = None
    while userFolder is not None:
        user = userFolder.getUserById(userId)
        if user is not None:
            break
        container = aq_parent(aq_inner(userFolder))
        parent = aq_parent(aq_inner(container))
        userFolder = getattr(parent, 'acl_users', None)
    
    if user is None:
        raise KeyError, "User %s cannot be found." % userId
    
    context.changeOwnership(user, False)

    def fixOwnerRole(context, userId):
        # Get rid of all other owners
        owners = context.users_with_local_role('Owner')
        for o in owners:
            roles = list(context.get_local_roles_for_userid(o))
            roles.remove('Owner')
            if roles:
                context.manage_setLocalRoles(o, roles)
            else:
                context.manage_delLocalRoles([o])
        roles = list(context.get_local_roles_for_userid(userId))
        roles.append('Owner')
        context.manage_setLocalRoles(userId, roles)

    fixOwnerRole(context, user.getId())
    catalog.reindexObject(context)