from zope.interface import implements
from zope.component import getUtility

from Products.CMFCore.utils import getToolByName

from Products.borg.config import PLACEFUL_WORKFLOW_POLICY
from Products.borg.interfaces import ILocalWorkflowSelection

class DefaultLocalWorkflowSelection(object):
    """Select the default local workflow policy.
    
    Local adapters or overrides may supercede this.
    """
    
    implements(ILocalWorkflowSelection)
    
    workflowPolicy = PLACEFUL_WORKFLOW_POLICY
    

def addLocalProjectWorkflow(ob, event):
    """Apply the local workflow for project spaces when a project is added.
    """
    
    # Add the TeamMember role if necessary
    if 'TeamMember' not in ob.validRoles():
        # Note: API sucks :-(
        ob.manage_defined_roles(submit='Add Role',
                                REQUEST={'role': 'TeamMember'})
    
    
    # Find out which workflow to use - this is looked up as a utility so
    # that other components can override it.
    workflowSelection = getUtility(ILocalWorkflowSelection, context=ob)
    
    # Set the placeful (local) workflow
    placeful_workflow = getToolByName(ob, 'portal_placeful_workflow')
    ob.manage_addProduct['CMFPlacefulWorkflow'].manage_addWorkflowPolicyConfig()
    config = placeful_workflow.getWorkflowPolicyConfig(ob)
    config.setPolicyBelow(policy=workflowSelection.workflowPolicy)