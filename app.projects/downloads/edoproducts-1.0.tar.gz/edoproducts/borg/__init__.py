from Products.CMFCore.utils import ContentInit
from Products.CMFCore.permissions import AddPortalContent
from Products.CMFCore.DirectoryView import registerDirectory

from Products.PluggableAuthService import registerMultiPlugin

from Products.Archetypes import process_types
from Products.Archetypes.public import listTypes

from Products.CMFPlone.interfaces import IPloneSiteRoot
from Products.GenericSetup import EXTENSION, profile_registry

from permissions import DEFAULT_ADD_CONTENT_PERMISSION, ADD_CONTENT_PERMISSIONS
from config import PROJECTNAME, GLOBALS

from permissions import AddUserFolders
from pas import localrole

registerDirectory('skins', GLOBALS)
registerMultiPlugin(localrole.ProjectLocalRoleManager.meta_type)

def initialize(context):

    # Register PAS plug-in
    
    context.registerClass(localrole.ProjectLocalRoleManager,
                          permission = AddUserFolders,
                          constructors = (localrole.manage_addProjectLocalRoleManagerForm,
                                          localrole.manage_addProjectLocalRoleManager),
                          visibility = None)

    # Register Archetypes content types
    
    import content

    contentTypes, constructors, ftis = process_types(listTypes(PROJECTNAME), PROJECTNAME)

    ContentInit(
        PROJECTNAME + ' Content',
        content_types      = contentTypes,
        permission         = DEFAULT_ADD_CONTENT_PERMISSION,
        extra_constructors = constructors,
        fti                = ftis,
        ).initialize(context)

    for i in range(0, len(contentTypes)):
        klassname = contentTypes[i].__name__
        if not klassname in ADD_CONTENT_PERMISSIONS:
            continue
        context.registerClass(meta_type    = ftis[i]['meta_type'],
                              constructors = (constructors[i],),
                              permission   = ADD_CONTENT_PERMISSIONS[klassname])
                              
    profile_registry.registerProfile('default',
                                     'Base organisation',
                                     'Organisation and project infrastructure',
                                     'profiles/default',
                                     'borg',
                                     EXTENSION,
                                     for_=IPloneSiteRoot)
