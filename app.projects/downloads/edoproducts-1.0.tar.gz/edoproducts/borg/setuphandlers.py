from StringIO import StringIO
from Products.CMFCore.utils import getToolByName
from Products.PlonePAS.Extensions.Install import activatePluginInterfaces

from config import LOCALROLES_PLUGIN_NAME, PLACEFUL_WORKFLOW_POLICY

def setupPlugins(portal, out):
    """Install and prioritize the project local-role PAS plug-in.
    """
    uf = getToolByName(portal, 'acl_users')

    borg = uf.manage_addProduct['borg']
    existing = uf.objectIds()

    if LOCALROLES_PLUGIN_NAME not in existing:
        borg.manage_addProjectLocalRoleManager(LOCALROLES_PLUGIN_NAME)
        print >> out, "Added Local Roles Manager."
        activatePluginInterfaces(portal, LOCALROLES_PLUGIN_NAME, out)

def setupPortalFactory(portal, out):
    """Add borg types to portal_factory
    """
    portal_factory = getToolByName(portal, 'portal_factory')
    if portal_factory is not None: 
        factoryTypes = list(portal_factory.getFactoryTypes().keys())
        for factoryType in ('Department', 'Employee', 'Project',):
            if factoryType not in factoryTypes:
                factoryTypes.append(factoryType)
        portal_factory.manage_setPortalFactoryTypes(listOfTypeIds = factoryTypes)
        print >> out, "Added borg types to portal_factory"

def addProjectPlacefulWorkflowPolicy(portal, out):
    """Add the placeful workflow policy used by project spaces.
    """
    placeful_workflow = getToolByName(portal, 'portal_placeful_workflow')
    if PLACEFUL_WORKFLOW_POLICY not in placeful_workflow.objectIds():
        placeful_workflow.manage_addWorkflowPolicy(PLACEFUL_WORKFLOW_POLICY, 
                                                   duplicate_id='portal_workflow')
        policy = placeful_workflow.getWorkflowPolicyById(PLACEFUL_WORKFLOW_POLICY)
        policy.setTitle('[borg] Project content workflows')
        policy.setDefaultChain(('borg_project_default_workflow',))
        policy.setChainForPortalTypes(('Folder', 'Large Plone Folder',), ('borg_project_default_workflow',))
        

def importVarious(context):
    """
    Import various settings.

    Provisional handler that does initialization that is not yet taken
    care of by other handlers.
    """
    site = context.getSite()
    out = StringIO()
    
    setupPlugins(site, out)
    setupPortalFactory(site, out)
    addProjectPlacefulWorkflowPolicy(site, out)
    
    logger = context.getLogger("borg")
    logger.info(out.getvalue())