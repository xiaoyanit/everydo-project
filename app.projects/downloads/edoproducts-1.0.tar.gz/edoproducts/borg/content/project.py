import types

from zope.interface import implements

from Acquisition import aq_inner, aq_parent
from AccessControl import ClassSecurityInfo

from Products.CMFCore.utils import getToolByName

from Products.Archetypes.atapi import *

from Products.borg.config import PROJECTNAME
from Products.borg.config import PROJECT_RELATIONSHIP
from Products.borg.config import PROJECT_MANAGER_RELATIONSHIP

from Products.borg import permissions

from Products.borg.interfaces import IEmployeeLocator
from Products.borg.interfaces import IValidRolesProvider
from Products.borg.interfaces import IAddableTypesProvider
from Products.borg.interfaces import IProjectContent

from schema import ExtensibleSchemaSupport

import utils

ProjectSchema = BaseSchema + Schema((

    ReferenceField('managers',
        relationship=PROJECT_MANAGER_RELATIONSHIP,
        allowed_types=('Employee',),
        vocabulary='listUsers',
        multiValued=True,
        languageIndependent=True,
        widget=ReferenceWidget(
            label=u'Project manager(s)',
            description=u"The manager(s) of this project."
            ),
        ),

    ReferenceField('members',
        relationship=PROJECT_RELATIONSHIP,
        allowed_types=('Employee',),
        vocabulary='listUsers',
        multiValued=True,
        languageIndependent=True,
        widget=ReferenceWidget(
            label=u'Project members',
            description=u"Members of this project. Note that managers are " \
                         "also members. You do not need to re-select project " \
                         "managers here.",
            ),
        ),
        
    LinesField('enabledContentTypes',
        default_method='defaultEnabledContentTypes',
        vocabulary='listAddableContentTypes',
        enforceVocabulary=True,
        languageIndependent=True,
        widget=MultiSelectionWidget(
            label=u'Addable types',
            description=u"Select the content types which team members will " \
                         "be able to add in this folder."
            ),
        ),
    ))


class Project(ExtensibleSchemaSupport, BaseFolder):
    """A project.
    
    Employees can be made members or managers of projects by reference.
    """
    
    implements(IProjectContent)
    
    security = ClassSecurityInfo()
    
    # Note: ExtensibleSchemaSupport means this may get expanded.
    schema = ProjectSchema
    _at_rename_after_creation = True
    
    #
    # Accesors, mutators and validators
    #
    
    security.declarePrivate('validate_id')
    def validate_id(self, value):
        """Ensure the id is unique, also among groups globally
        """
        if value != self.getId():
            parent = aq_parent(aq_inner(self))
            if value in parent.objectIds():
                return "An object with id '%s' already exists in this folder" % value
        
            groups = getToolByName(self, 'portal_groups')
            if groups.getGroupById(value) is not None:
                return "A group with the id '%s' already exists in the portal" % value
    
    security.declareProtected(permissions.ModifyPortalContent, 'setEnabledContentTypes')
    def setEnabledContentTypes(self, value):
        """Make sure the given types are enabled
        """
        self.getField('enabledContentTypes').set(self, value)
        if type(value) in (types.ListType, types.TupleType,):
            provider = IAddableTypesProvider(self)
            utils.enableAddingTypes(self, provider.availableTypes, value, 'TeamMember')
    
    #
    # Vocabulary methods
    #
    
    security.declarePrivate('listUsers')
    def listUsers(self):
        """Return a DisplayList of users
        """
        locator = IEmployeeLocator(self)
        return DisplayList(locator.employees)

    security.declarePrivate('listAddableContentTypes')
    def listAddableContentTypes(self):
        """Return a DisplayList of addable content types that may be enabled.
        """
        provider = IAddableTypesProvider(self)
        return DisplayList([(t.getId(), t.Title(),) for t in provider.availableTypes])

    security.declarePrivate('defaultEnabledContentTypes')
    def defaultEnabledContentTypes(self):
        """Return a list of addable content types to select by default.
        """
        provider = IAddableTypesProvider(self)
        return [t.getId() for t in provider.defaultAddableTypes]
        

registerType(Project, PROJECTNAME)
