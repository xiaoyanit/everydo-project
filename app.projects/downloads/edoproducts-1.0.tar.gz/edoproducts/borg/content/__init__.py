"""Archetypes content types and supporting infrastructure
"""

from department import Department
from employee import Employee
from project import Project