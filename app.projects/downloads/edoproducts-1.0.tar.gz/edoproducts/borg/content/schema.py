"""Provide variable schema support. A class can mix in ExtensibleSchemaSupport
(preferably as the first base class), and define a 'schema' class variable as
normal. Upon first access to Schema(), an extended schema will be calculated
by adapting the object to ISchemaExtender and (if such an adapter can be found)
giving it the opportunity to extend the schema.

The extension should happen at least once for every class for every Zope 
restart, but may be cached thereafter. To invalidate the cache for a particular
class, send an ISchemaInvalidatedEvent. The implementation in 
SchemaInvalidatedEvent below should be sufficient.
"""

from zope.interface import implements
from zope.component import queryAdapter

from AccessControl import ClassSecurityInfo
from Acquisition import ImplicitAcquisitionWrapper
from Globals import InitializeClass
from ExtensionClass import Base

from Products.Archetypes.ClassGen import ClassGenerator, Generator
from Products.CMFCore import permissions

from Products.borg.interfaces import ISchemaInvalidatedEvent
from Products.borg.interfaces import IExtensibleSchemaProvider
from Products.borg.interfaces import ISchemaExtender

# Holds loaded schemas, keyed by class. Thus, schemas will be calculated once
# (on first access) and stored in memory. If they are removed from the dict,
# they may be re-calculated. The ISchemaInvalidatedEvent event type can be
# used to invalidate a schema

loadedSchemas={}

#
# Generator
#

class VarClassGen(ClassGenerator):
    """A version of Archetypes' ClassGen that is able to generate a class
    based on an explicitly given schema. 
    
    This is taken from VariableSchemaSupport in Archetypes, but modernised a 
    bit.
    """

    def __init__(self, schema):
        self.schema = schema

    def updateMethods(self, klass):
        """Update the methods of the klass to support a new schema.
        
        This will re-generate methods.
        """
        self.generateMethods(klass, self.schema.fields())

#
# Mix-in class
#

class ExtensibleSchemaSupport(Base):
    """Mixin class to support instance-based schemas.
    
    Note: you must mix this in before BaseFolder or BaseContent, e.g.:

    class Foo(ExtensibleSchemaSupport, BaseContent):
        ...

    This is based on Archetype's VariableSchemaSupport.
    
    Define a content type with a marker interface:
    
    >>> from zope.interface import Interface, implements
    >>> class IMyType(Interface):
    ...     pass
    
    >>> from Products.Archetypes.atapi import *
    >>> from Products.borg.content.schema import ExtensibleSchemaSupport
    >>> class MyType(ExtensibleSchemaSupport, BaseObject):
    ...     implements(IMyType)
    ...     schema = BaseSchema.copy() + Schema((StringField('foo'),))
    >>> registerType(MyType, 'testing')
    
    Create a schema extender:
    
    >>> from Products.borg.interfaces import ISchemaExtender
    >>> class Extender(object):
    ...     implements(ISchemaExtender)
    ...     def __init__(self, context):
    ...         self.context = context
    ...     def extend(self, schema):
    ...         return schema.copy() + Schema((StringField('bar'),))
    
    >>> from zope.app.tests import ztapi
    >>> ztapi.provideAdapter(IMyType, ISchemaExtender, Extender)
    
    Verify that the extended schema is in the Schema() of the object:
    
    >>> m = MyType('id')
    
    >>> from Acquisition import aq_base
    >>> schema = aq_base(m.Schema())
    >>> 'foo' in schema
    True
    >>> 'bar' in schema
    True
    >>> 'baz' in schema
    False
    
    We could set a different base schema. However, it won't take effect until 
    the schema is invalidated.
    
    >>> m.schema = BaseSchema.copy() + Schema((IntegerField('baz'),))
    >>> schema = aq_base(m.Schema())
    >>> 'baz' in schema
    False
    
    The schema can be invalidated (and thus re-initialised) by firing an
    ISchemaInvalidatedEvent event.
    
    >>> from zope.event import notify
    >>> from Products.borg.content.schema import SchemaInvalidatedEvent
    >>> notify(SchemaInvalidatedEvent(m.__class__))
    
    Now the new schema should be in effect:
    
    >>> schema = aq_base(m.Schema())
    >>> 'foo' in schema
    False
    >>> 'bar' in schema
    True
    >>> 'baz' in schema
    True
    
    Note that accessors and mutators also work, since ClassGen is being called:
    
    >>> m.setBar('one')
    >>> m.getBar()
    'one'
    >>> m.getRawBar()
    'one'
    """
    implements(IExtensibleSchemaProvider)
    security = ClassSecurityInfo()

    security.declareProtected(permissions.View, 'Schema')
    def Schema(self):
        """Get the schema, and initialise the class if necessary.
        """
        schema = loadedSchemas.get(self.__class__, None)
        if schema is None:
            schema = self.schema
            extender = queryAdapter(self, ISchemaExtender, context=self)
            if extender is not None:
                schema = extender.extend(schema)
            generator = VarClassGen(schema)
            generator.updateMethods(self.__class__)
            loadedSchemas[self.__class__] = schema
            
        return ImplicitAcquisitionWrapper(schema, self)

InitializeClass(ExtensibleSchemaSupport)

#
# Events
#

class SchemaInvalidatedEvent(object):
    """Event fired when the schema of an Archetypes object using
    IExtensibleSchemaProvider is invalidated.
    """
    implements(ISchemaInvalidatedEvent)
    
    def __init__(self, klass):
        self.klass = klass

def invalidateSchema(event):
    """React to an ISchemaInvalidatedEvent by invalidating the required schema.
    """
    klass = event.klass
    if klass in loadedSchemas:
        del loadedSchemas[klass]