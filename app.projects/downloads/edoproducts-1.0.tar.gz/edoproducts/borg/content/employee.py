from sha import sha

from zope.interface import implements
from zope.event import notify

from zope.app.annotation.interfaces import IAttributeAnnotatable, IAnnotations

from Acquisition import aq_inner, aq_parent
from AccessControl import ClassSecurityInfo

from Products.CMFCore.utils import getToolByName

from Products.Archetypes.atapi import *

from Products.membrane.interfaces import IUserAuthProvider
from Products.membrane.interfaces import IPropertiesProvider
from Products.membrane.interfaces import IGroupsProvider
from Products.membrane.interfaces import IGroupAwareRolesProvider
from Products.membrane.interfaces import IUserChanger

from Products.borg.interfaces import IValidRolesProvider
from Products.borg.interfaces import IEmployeeContent
from Products.borg.interfaces import IEmployeeModifiedEvent

from Products.borg import permissions
from Products.borg.config import PROJECTNAME, PASSWORD_KEY, INVALID_ROLES

from schema import ExtensibleSchemaSupport

EmployeeSchema = BaseSchema.copy() + Schema((

    StringField('id',
        languageIndependent=True,
        required=True,
        write_permission=permissions.ManageUsers,
        widget=StringWidget(
            label=u'User name',
            description=u"Username for this employee.",
        ),
    ),
               
    StringField('password',
        languageIndependent=True,
        required=False,
        mode='w',
        write_permission=permissions.SetPassword,
        widget=PasswordWidget(
            label=u'Password',
            description=u"Password for this employee. " \
                         "(Leave this blank if you don't want to change the password)",
        ),
    ),
     
    StringField('confirmPassword',
        languageIndependent=True,
        required=False,
        mode='w',
        write_permission=permissions.SetPassword,
        widget=PasswordWidget(
            label=u'Confirm password',
            description=u"Please re-enter the password. " \
                         "(Leave this blank if you don't want to change the password)",
        ),
    ),         

    # Can't use 'roles' because 'validate_roles' exists :-(
    LinesField('roles_',
        accessor='getRoles',
        mutator='setRoles',
        edit_accessor='getRawRoles',
        languageIndependent=True,
        vocabulary='getRoleSet',
        multiValued=True,
        write_permission=permissions.ManageUsers,
        widget=MultiSelectionWidget(
            label=u'Roles',
            description=u"The roles this employee will have",
            ),
        ),
    ))

class EmployeeModifiedEvent(object):
    """Event to notify that employees have been saved.
    """
    implements(IEmployeeModifiedEvent)
    
    def __init__(self, context):
        self.context = context

class Employee(ExtensibleSchemaSupport, BaseContent):
    """A borg employee.
    
    Employees are also users.
    """
    
    implements(IEmployeeContent,
               # Mark employees as sources of user authentication
               IUserAuthProvider,
               # Enable simple membrane user properties
               IPropertiesProvider,
               # Mark employees are given groups by containment or backrefs
               IGroupsProvider,
               # Mark employees as given roles explicitly and from groups
               IGroupAwareRolesProvider, 
               # Employees are attribute annotatable
               IAttributeAnnotatable,
               # Employees can set their own passwords
               IUserChanger)
                
    security = ClassSecurityInfo()
     
    # Note: ExtensibleSchemaSupport means this may get expanded.
    schema = EmployeeSchema
    _at_rename_after_creation = False
    
    #
    # Event support
    #
    
    # XXX: A generic event really should be fired from Archetypes
    
    security.declarePrivate(permissions.View, 'at_post_create_script')
    def at_post_create_script(self):
        """Notify that the employee has been saved.
        """
        notify(EmployeeModifiedEvent(self))
    
    security.declarePrivate(permissions.View, 'at_post_edit_script')
    def at_post_edit_script(self):
        """Notify that the employee has been saved.
        """
        notify(EmployeeModifiedEvent(self))
    
    #
    # Accessors, mutators and validators
    #
    
    security.declareProtected(permissions.SetPassword, 'setPassword')
    def setPassword(self, value):
        if value:
            annotations = IAnnotations(self)
            annotations[PASSWORD_KEY] = sha(value).digest()
        
    security.declareProtected(permissions.SetPassword, 'setConfirmPassword')
    def setConfirmPassword(self, value):
        # Do nothing - this value is used for verification only
        pass
    
    security.declarePrivate('validate_id')
    def validate_id(self, value):
        """Ensure the id is unique, also among groups globally
        """
        if value != self.getId():
            parent = aq_parent(aq_inner(self))
            if value in parent.objectIds():
                return "An object with id '%s' already exists in this folder" % value
        
            membership = getToolByName(self, 'portal_membership')
            if membership.getMemberById(value) is not None:
                return "A user with id '%s' already exists in the portal" % value
            
    security.declarePrivate('post_validate')
    def post_validate(self, REQUEST, errors):
        form = REQUEST.form
        if form.has_key('password') or form.has_key('confirmPassword'):
            password = form.get('password', None)
            confirm = form.get('confirmPassword', None)

            annotations = IAnnotations(self)
            passwordDigest = annotations.get(PASSWORD_KEY, None) 
            
            if not passwordDigest:
                if not password and not confirm:
                    errors['password'] = u'An initial password must be set'
                    return
            if password or confirm:
                if password != confirm:
                    errors['password'] = errors['confirmPassword'] = u'Passwords do not match'
    
    #
    # Vocabulary methods
    #
    
    security.declarePrivate('getRoleSet')
    def getRoleSet(self):
        """Get the roles vocabulary to use
        """
        provider = IValidRolesProvider(self)
        return provider.availableRoles

registerType(Employee, PROJECTNAME)
