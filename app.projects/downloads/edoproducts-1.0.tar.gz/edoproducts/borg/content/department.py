from zope.interface import implements

from Acquisition import aq_inner, aq_parent
from AccessControl import ClassSecurityInfo

from Products.CMFCore.utils import getToolByName

from Products.Archetypes.atapi import *

from Products.membrane.interfaces import IPropertiesProvider

from Products.borg.interfaces import IEmployeeLocator
from Products.borg.interfaces import IValidRolesProvider
from Products.borg.interfaces import IDepartmentContent

from Products.borg.config import PROJECTNAME, INVALID_ROLES
from Products.borg import permissions

from schema import ExtensibleSchemaSupport

DepartmentSchema = BaseSchema.copy() + Schema((

    ReferenceField('managers',
        relationship='managesDepartment',
        allowed_types=('Employee',),
        vocabulary='listUsers',
        multiValued=1,
        languageIndependent=True,
        widget=ReferenceWidget(
            label=u'Department manager',
            description=u"The manager of this department."
            ),
        ),

    # Can't use 'roles' because 'validate_roles' exists :-(
    LinesField('roles_',
        accessor='getRoles',
        mutator='setRoles',
        edit_accessor='getRawRoles',
        languageIndependent=True,
        vocabulary='getRoleSet',
        multiValued=1,
        write_permission=permissions.ManageUsers,
        widget=MultiSelectionWidget(
            label=u'Roles',
            description=u"The roles all employees in this department will have",
            ),
        ),
    ))


class Department(ExtensibleSchemaSupport, BaseFolder):
    """A borg department.
    
    Departments can contain other employees.
    """
    
    implements(IDepartmentContent, IPropertiesProvider)
    
    security = ClassSecurityInfo()
        
    # Note: ExtensibleSchemaSupport means this may get expanded.
    schema = DepartmentSchema
    _at_rename_after_creation = True

    #
    # Validators
    #
    
    security.declarePrivate('validate_id')
    def validate_id(self, value):
        """Ensure the id is unique, also among groups globally
        """
        if value != self.getId():
            parent = aq_parent(aq_inner(self))
            if value in parent.objectIds():
                return "An object with id '%s' already exists in this folder" % value
        
            groups = getToolByName(self, 'portal_groups')
            if groups.getGroupById(value) is not None:
                return "A group with id '%s' already exists in the portal" % value
        
    
    #
    # Vocabulary methods
    #
    
    security.declarePrivate('listUsers')
    def listUsers(self):
        """Return a DisplayList of users
        """
        locator = IEmployeeLocator(self)
        return DisplayList(locator.employees)
    
    security.declarePrivate('getRoleSet')
    def getRoleSet(self):
        """Get the roles vocabulary to use
        """
        provider = IValidRolesProvider(self)
        return provider.availableRoles

registerType(Department, PROJECTNAME)
