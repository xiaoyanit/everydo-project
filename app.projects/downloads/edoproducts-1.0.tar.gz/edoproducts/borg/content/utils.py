from zope.interface import Interface
from zope.interface import implements
from zope.component import adapts

from AccessControl.ZopeSecurityPolicy import getRoles

from Products.CMFCore.utils import getToolByName
from Products.membrane.config import TOOLNAME as MEMBRANE_TOOL

from Products.borg.interfaces import IEmployeeContent

from Products.borg.interfaces import IEmployeeLocator
from Products.borg.interfaces import IAddableTypesProvider
from Products.borg.interfaces import IValidRolesProvider

from Products.borg.config import INVALID_ROLES

class EmployeeLocator(object):
    """Default employee locator

    Uses membrane_tool to perform a search.
    """

    implements(IEmployeeLocator)
    adapts(Interface)

    def __init__(self, context):
        self.context = context

    @property
    def employees(self):
        catalog = getToolByName(self.context, MEMBRANE_TOOL)
        results = catalog(object_implements=IEmployeeContent.__identifier__)
        value = []
        for r in results:
            key = r.getUserName is not None and \
                  r.getUserName.strip() or r.getUserId
            value.append((key.lower(), (r.UID, r.Title)))
        value.sort()
        return [r for throwaway, r in value]

class AddableTypesProvider(object):
    """Default addable types provider.

    Finds all globally allowed content types.
    """

    implements(IAddableTypesProvider)
    adapts(Interface)

    def __init__(self, context):
        self.context = context

    @property
    def availableTypes(self):
        """Return all types globally allowed
        """
        portal_types = getToolByName(self.context, 'portal_types')
        types = []
        for typeInfo in portal_types.listTypeInfo():
            if getattr(typeInfo, 'globalAllow', lambda: False)() == True:
                types.append(typeInfo)
        return tuple(types)

    @property
    def defaultAddableTypes(self):
        """Return all globally allowed types where the factory permission
        is given to the Owner role.
        """

        dispatcher = getattr(self.context, 'manage_addProduct', None)
        types = []

        for typeInfo in self.availableTypes:
            rolePermission = _getRolePermissionForTypeInfo(self.context, typeInfo)
            if rolePermission is not None:
                if 'Owner' in rolePermission.__of__(self.context):
                    types.append(typeInfo)

        return tuple(types)

class ValidRolesProvider(object):
    """Default valid roles provider.

    Finds all valid roles in the context, less roles set in INVALID_ROLES in
    config.py.
    """

    implements(IValidRolesProvider)
    adapts(Interface)

    def __init__(self, context):
        self.context = context

    @property
    def availableRoles(self):
        roles = [r for r in self.context.validRoles() if r not in INVALID_ROLES]
        return tuple(roles)

def enableAddingTypes(context, allTypes, selectedTypeIds, role):
    """Give the given role the add permission on all the selected types.

    allTypes is a list of ITypeInformation objects. selectedTypeIds is a list
    of ids for such type infos. The permission for each type id will be found
    and will be managed on the context so that the given role is only set
    for the selected types. Permissions will be set to acquire.
    """
    for typeInfo in allTypes:
        typeId = typeInfo.getId()

        permission = getFactoryPermission(context, typeInfo)
        if permission is not None:
            roles = [r['name'] for r in context.rolesOfPermission(permission) if r['selected']]
            acquire = bool(context.permission_settings(permission)[0]['acquire'])
            if typeId in selectedTypeIds and role not in roles:
                roles.append(role)
            elif typeId not in selectedTypeIds and role in roles:
                roles.remove(role)
            context.manage_permission(permission, roles, acquire)


def getFactoryPermission(context, typeInfo):
    """Return the factory perimssion of the given type information object.
    """
    rolePermission = _getRolePermissionForTypeInfo(context, typeInfo)
    if rolePermission is None:
        return None
    return rolePermission.__name__

def _getRolePermissionForTypeInfo(context, typeInfo):
    """Helper method to get hold of a RolePermission for a given FTI.
    """
    factory = getattr(typeInfo, 'factory', None)
    product = getattr(typeInfo, 'product', None)
    dispatcher = getattr(context, 'manage_addProduct', None)

    if factory is None or product is None or dispatcher is None:
        return None

    try:
        productInstance = dispatcher[product]
    except AttributeError:
        return None

    factoryMethod = getattr(productInstance, factory, None)
    if factoryMethod is None:
        return None

    factoryInstance = getattr(factoryMethod, 'im_self', None)
    if factoryInstance is None:
        return None

    factoryClass = factoryInstance.__class__
    rolePermission = getattr(factoryClass, factory+'__roles__', None)
    if rolePermission is None:
        return None

    return rolePermission