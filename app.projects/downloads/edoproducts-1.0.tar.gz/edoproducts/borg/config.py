PROJECTNAME = 'borg'
GLOBALS = globals()

# Name of the Local Roles PAS plug-in
LOCALROLES_PLUGIN_NAME = 'borg_localroles'

# Relationships used for reference fields
PROJECT_RELATIONSHIP = 'participatesInProject'
PROJECT_MANAGER_RELATIONSHIP = 'managesProject'
DEPARTMENT_MANAGER_RELATIONSHIP = 'managesDepartment'

# Annotation key used for passwords
PASSWORD_KEY = 'borg.employee.password'

# Placeful workflow policy id used for projects
PLACEFUL_WORKFLOW_POLICY = 'project_placeful_workflow'

# Roles filtered out from selection
INVALID_ROLES = ('Anonymous', 'Authenticated', 'Owner', 'TeamMember',)