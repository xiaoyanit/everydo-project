"""Integration tests for employees.
"""

import unittest
from Testing.ZopeTestCase import ZopeDocTestSuite

from base import BorgTestCase
from utils import optionflags

def test_creation():
    """Test that employees can be created an initiated.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept')
    >>> id = self.portal.dept.invokeFactory('Employee', 'emp')
    >>> emp = self.portal.dept.emp
    
    Set a title.
    
    >>> emp.setTitle('E. M. Ployee')
    >>> emp.Title()
    'E. M. Ployee'
    
    Set a password (note that the password cannot be read back directly.)
    
    >>> emp.setPassword('secret')
    >>> emp.getPassword()
    Traceback (most recent call last):
    ...
    AttributeError: getPassword
    
    >>> emp.setConfirmPassword('secret')
    >>> emp.getConfirmPassword()
    Traceback (most recent call last):
    ...
    AttributeError: getConfirmPassword
    
    Set roles.
    
    >>> emp.setRoles(('Reviewer',))
    >>> emp.getRoles()
    ('Reviewer',)
    """

def test_employee_is_user():
    """Verify that that employee acts as a user.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp1')
    >>> self.portal.portal_membership.getMemberById('emp1')
    <MemberData at .../emp1 used for ...>
    """

def test_getRoleSet():
    """Test the getRoleSet vocab method.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> dept = self.portal.dept1
    >>> id = dept.invokeFactory('Employee', 'emp1')
    >>> emp = dept.emp1
    
    The getRoleSet() method should return all portal-wide roles except 
    Anonymous, Authenticated, Owner and TeamMember.
    
    >>> roles = list(emp.getRoleSet())
    >>> roles.sort()
    >>> roles
    ['Manager', 'Member', 'Reviewer']
    """

def test_iemployee():
    """Test the functionality of the IEmployee adapter.
    
    >>> from Products.borg.interfaces import IEmployee
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept')
    >>> id = self.portal.dept.invokeFactory('Employee', 'emp', title='E. M. Ployee')
    >>> emp = self.portal.dept.emp
    
    Adapt to IEmployee
    
    >>> e = IEmployee(emp)
    
    The id is obtained from the content object (global uniqueness is enforced).
    
    >>> e.id
    'emp'
    
    The fullname is obtained from the object's Title.
    
    >>> e.fullname
    'E. M. Ployee'
    """

def test_iuserrelated():
    """Test the functionality of the IUserRelated adapter.
    
    >>> from Products.membrane.interfaces import IUserRelated
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept')
    >>> id = self.portal.dept.invokeFactory('Employee', 'emp')
    >>> emp = self.portal.dept.emp
    
    Adapt to IUserRelated
    
    >>> u = IUserRelated(emp)
    
    The user id is obtained from the content object's id (global uniqueness is
    enforced).
    
    >>> u.getUserId()
    'emp'
    """

def test_iuserauthprovider():
    """Test the functionality of the IUserAuthentication adapter.
    
    >>> from Products.membrane.interfaces import IUserAuthentication
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept')
    >>> id = self.portal.dept.invokeFactory('Employee', 'emp')
    >>> emp = self.portal.dept.emp
    
    Adapt to IUserAuthentication
    
    >>> u = IUserAuthentication(emp)
    
    The user name is the same as the user id, and is obtained from the content 
    object's id (global uniqueness is enforced).
    
    >>> u.getUserName()
    'emp'
    
    Credentials are verified against the user name and the password.
    
    >>> emp.setPassword('secret')
    >>> u.verifyCredentials({})
    False
    >>> u.verifyCredentials({'login' : '',      'password' : ''})
    False
    >>> u.verifyCredentials({'login' : 'emp',   'password' : ''})
    False
    >>> u.verifyCredentials({'login' : '',      'password' : 'secret'})
    False
    >>> u.verifyCredentials({'login' : 'wrong', 'password' : 'incorrect'})
    False
    >>> u.verifyCredentials({'login' : 'emp',   'password' : 'incorrect'})
    False
    >>> u.verifyCredentials({'login' : 'wrong', 'password' : 'secret'})
    False
    >>> u.verifyCredentials({'login' : 'emp',   'password' : 'secret'})
    True
    """

def test_getMemberById():
    """Verify that getMemberById works.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept')
    >>> id = self.portal.dept.invokeFactory('Employee', 'emp')
    >>> emp = self.portal.dept.emp
    
    >>> from Products.CMFCore.utils import getToolByName
    >>> membership = getToolByName(self.portal, 'portal_membership')
    >>> membership.getMemberById('emp')
    <MemberData at .../portal_memberdata/emp used for .../acl_users>
    """
    
def test_login():
    """Test the employees can log in
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept')
    >>> id = self.portal.dept.invokeFactory('Employee', 'emp')
    >>> emp = self.portal.dept.emp
    
    >>> self.logout()
    >>> self.login('emp')
    
    >>> from Products.CMFCore.utils import getToolByName
    >>> membership = getToolByName(self.portal, 'portal_membership')
    >>> membership.getAuthenticatedMember()
    <MemberData at .../portal_memberdata/emp used for .../acl_users>
    """
    
def test_ownership():
    """Verify that employees are given ownership over their own objects when
    created. 
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept')
    >>> id = self.portal.dept.invokeFactory('Employee', 'emp')
    >>> emp = self.portal.dept.emp
    
    Simulate Archetypes' setting of fields, re-indexing and calling the 
    post-create script.
    
    >>> emp.setTitle('Employee One')
    >>> emp.reindexObject()
    >>> emp.at_post_create_script()
    
    >>> emp.getOwnerTuple()[1]
    'emp'
    """
    
def test_ownership_after_edit():
    """Verify that employees are given ownership over their own objects when
    edited.
    
    Note - this isn't a full test, it only verifies that at_post_edit_script()
    does what it should do.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept')
    >>> id = self.portal.dept.invokeFactory('Employee', 'emp')
    >>> emp = self.portal.dept.emp
    
    Simulate Archetypes' setting of fields, re-indexing and calling the 
    post-edit script.
    
    >>> emp.setTitle('Employee One')
    >>> emp.reindexObject()
    >>> emp.at_post_edit_script()
    
    >>> emp.getOwnerTuple()[1]
    'emp'
    """

def test_validate_id():
    """Verify that the validate_id method checks global uniqueness of member ids.
    
    >>> self.setRoles(('Manager',))
    >>> from Testing.ZopeTestCase import user_name
    
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> id = self.portal.invokeFactory('Department', 'dept2')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp2')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp3')
    >>> emp = self.portal.dept1.emp1
    
    Choosing an id that already exists in the folder or an id for a member
    that already exists results in a validation error. We only test that the
    offending id is mentioned in the error, to avoid being dependent on the
    exact wording of the message.
    
    >>> emp.validate_id('foo') == None
    True
    
    >>> emp.validate_id('dept1') == None
    True
    
    >>> emp.validate_id('proj1') == None
    True
    
    >>> 'emp2' in emp.validate_id('emp2')
    True
        
    >>> 'emp3' in emp.validate_id('emp3')
    True
    
    >>> user_name in emp.validate_id(user_name)
    True
    """

def test_iusermanagement():
    """Test the functionality of the IUserManagement adapter.
    
    >>> from Products.membrane.interfaces import IMembraneUserManagement
    >>> from Products.membrane.interfaces import IUserAuthentication
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept')
    >>> id = self.portal.dept.invokeFactory('Employee', 'emp')
    >>> emp = self.portal.dept.emp
    
    Adapt to IMembraneUserManagement and use an IUserAuthentication for
    testing our changes
    
    >>> u = IMembraneUserManagement(emp)
    >>> auth = IUserAuthentication(emp)
    
    Set a password directly and see that it verifies
    
    >>> emp.setPassword('secret')
    >>> auth.verifyCredentials({'login' : 'emp',   'password' : 'secret'})
    True

    Set a password using our plugin and test that it has been changed:

    >>> u.doChangeUser('emp', 'secret2')
    >>> auth.verifyCredentials({'login' : 'emp',   'password' : 'secret2'})
    True

    Set a password and another property using a kwarg:

    >>> emp.getRoles()
    ()
    >>> u.doChangeUser('emp', 'secret', roles_=('Member',))
    >>> emp.getRoles()
    ('Member',)

    Delete the user:
    >>> hasattr(self.portal.dept, 'emp')
    True
    >>> u.doDeleteUser('emp')
    >>> hasattr(self.portal.dept, 'emp')
    False

    We should no longer be able to login as this user:

    >>> self.logout()
    >>> self.login('emp')
    Traceback (most recent call last):
    ...
        user = user.__of__(uf)
    AttributeError: 'NoneType' object has no attribute '__of__'

    """

def test_suite():
    return unittest.TestSuite((
            ZopeDocTestSuite(test_class=BorgTestCase,
                             optionflags=optionflags),
        ))
