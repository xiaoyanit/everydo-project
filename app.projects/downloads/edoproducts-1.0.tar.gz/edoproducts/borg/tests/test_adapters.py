"""Integration tests for adapter registrations.

These tests ensure that the various adapter registrations are in effect,
not the exact functionality they promise. They utilise the full PloneTestCase
bases, since we are actually testing that the registrations are properly loaded
at Zope start-up, not just that they could be made to work (e.g. using the
zope testing API)
"""

import unittest
from Testing.ZopeTestCase import ZopeDocTestSuite

from base import BorgTestCase
from utils import optionflags

def test_department():
    """A department content object can be used to provide group functionality 
    with membrane, and to hold semantic information about a department.
    
    >>> from Products.membrane.interfaces import IGroup
    >>> from Products.borg.interfaces import IDepartment
    >>> from Products.borg.interfaces import IWorkspace
    
    Create a content object to work from.
    
    >>> self.setRoles(('Manager'),)
    >>> self.portal.invokeFactory('Department', 'dept')
    'dept'
    >>> dept = self.portal.dept
    
    IDepartment contains the semantic information about a department.
    
    >>> IDepartment(dept)
    <Products.borg.membership.department.Department object at ...>
    
    IGroup is a membrane interface that lets the department act as a group 
    for the employees it contains.
    
    >>> IGroup(dept)
    <Products.borg.membership.department.Group object at ...>
    
    IWorkspace is used by the ProjectLocalRoles PAS plug-in to let managers
    of this department gain the 'manager' role.
    
    >>> IWorkspace(dept)
    <Products.borg.membership.department.LocalRoles object at ...>
    
    """

def test_employee():
    """An employee content object can be adapted to various membrane interfaces
    to provide user functionality, and also hold semantic employee information.
    
    >>> from Products.membrane.interfaces import IUserRelated
    >>> from Products.membrane.interfaces import IUserAuthentication
    >>> from Products.membrane.interfaces import IUserRoles
    >>> from Products.membrane.interfaces import IMembraneUserManagement
    >>> from Products.borg.interfaces import IEmployee
    
    Create a content object to work from
    
    >>> self.setRoles(('Manager'),)
    >>> self.portal.invokeFactory('Department', 'dept')
    'dept'
    >>> self.portal.dept.invokeFactory('Employee', 'emp')
    'emp'
    >>> emp = self.portal.dept.emp
    
    IEmployee contains semantic information about an employee
    
    >>> IEmployee(emp)
    <Products.borg.membership.employee.Employee object at ...>
    
    IUserRelated gives membrane a way of obtaining a user id from an employee.
    
    >>> IUserRelated(emp)
    <Products.borg.membership.employee.UserRelated object at ...>
    
    IUserAuthentication provides methods for membrane to authenticate against an
    employee as a user.
    
    >>> IUserAuthentication(emp)
    <Products.borg.membership.employee.UserAuthentication object at ...>
    
    IUserRoles lets employees specify their user roles.
    
    >>> IUserRoles(emp)
    <Products.borg.membership.employee.UserRoles object at ...>
    
    IMembraneUserManagement provides methods for adding deleting and changing
    users
    
    >>> IMembraneUserManagement(emp)
    <Products.borg.membership.employee.UserManagement object at ...>
    
    """

def test_project():
    """A project content object can be used to provide group functionality 
    with membrane, and to hold semantic information about a project.
    
    >>> from Products.membrane.interfaces import IGroup
    >>> from Products.borg.interfaces import IProject
    >>> from Products.borg.interfaces import IWorkspace
    
    Create a content object to work from.
    
    >>> self.setRoles(('Manager'),)
    >>> self.portal.invokeFactory('Project', 'proj')
    'proj'
    >>> proj = self.portal.proj
    
    IDepartment contains the semantic information about a department.
    
    >>> IProject(proj)
    <Products.borg.membership.project.Project object at ...>
    
    IGroup is a membrane interface that lets the project act as a group 
    for the employees it that are managers and members of it.
    
    >>> IGroup(proj)
    <Products.borg.membership.project.Group object at ...>
    
    IWorkspace is used by the ProjectLocalRoles PAS plug-in to let managers
    of this project gain the 'manager' role.
    
    >>> IWorkspace(proj)
    <Products.borg.membership.project.LocalRoles object at ...>
    """
    
def test_utils():
    """Test various utility adapters
    
    >>> from Products.borg.interfaces import IEmployeeLocator
    >>> from Products.borg.interfaces import IAddableTypesProvider
    >>> from Products.borg.interfaces import IValidRolesProvider
    
    These are registered for any interface.
    
    >>> from zope.interface import Interface, implements
    >>> class MyClass(object):
    ...     implements(Interface)
    
    >>> c = MyClass()
    
    An employee locator can find a list of available employees for selection.
    
    >>> IEmployeeLocator(c)
    <Products.borg.content.utils.EmployeeLocator object at ...>
    
    An addable types provider can find a list of types that may be added in
    a given location.
    
    >>> IAddableTypesProvider(c)
    <Products.borg.content.utils.AddableTypesProvider object at ...>
    
    A valid roles provide can find a list of roles valid for selection.
    
    >>> IValidRolesProvider(c)
    <Products.borg.content.utils.ValidRolesProvider object at ...>
    
    """
    
def test_suite():
    return unittest.TestSuite((
            ZopeDocTestSuite(test_class=BorgTestCase,
                             optionflags=optionflags),
        ))
