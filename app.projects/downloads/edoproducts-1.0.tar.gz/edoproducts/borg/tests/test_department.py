"""Integration tests for departments.
"""

import unittest
from Testing.ZopeTestCase import ZopeDocTestSuite

from base import BorgTestCase
from utils import optionflags

def test_creation():
    """Test that departments can be created an initiated.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept')
    >>> dept = self.portal.dept
    
    Set roles.
    
    >>> dept.setRoles(('Reviewer',))
    >>> tuple(dept.getRoles())
    ('Reviewer',)
    
    Add an employee and set it as a manager.
    
    >>> id = dept.invokeFactory('Employee', 'emp')
    >>> dept.setManagers((dept.emp.UID(),))
    >>> tuple(dept.getManagers())
    (<Employee at ...>,)
    """
    
def test_department_is_group():
    """Verify that that department acts as a group.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> self.portal.portal_groups.getGroupById('dept1')
    <GroupData at .../dept1 used for ...>
    """

def test_listUsers():
    """Test the listUsers() vocab method.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> id = self.portal.invokeFactory('Department', 'dept2')
    >>> dept = self.portal.dept1
    
    Add some employees
    
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp1', title='Emp1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp2', title='Emp2')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp3', title='Emp3')
    
    Check that listUsers returns all of them. Titles are used as names.
    
    >>> values = list(dept.listUsers().values())
    >>> values.sort()
    >>> values
    ['Emp1', 'Emp2', 'Emp3']
    """

def test_getRoleSet():
    """Test the getRoleSet vocab method.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> dept = self.portal.dept1
    
    The getRoleSet() method should return all portal-wide roles except 
    Anonymous, Authenticated, Owner and TeamMember.
    
    >>> roles = list(dept.getRoleSet())
    >>> roles.sort()
    >>> roles
    ['Manager', 'Member', 'Reviewer']
    """

def test_idepartment():
    """Test the functionality of the IDepartment adapter.
    
    >>> from Products.borg.interfaces import IDepartment
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept')
    >>> dept = self.portal.dept
    >>> dept.setRoles(('Reviewer',))
    
    >>> id = dept.invokeFactory('Employee', 'emp1')
    >>> id = dept.invokeFactory('Employee', 'emp2')
    >>> id = dept.invokeFactory('Employee', 'emp3')
    
    >>> id = self.portal.invokeFactory('Department', 'dept2')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp4')
    
    Now adapt to IDepartment
    
    >>> d = IDepartment(dept)
    
    The id should be taken directly from the content object
    
    >>> d.id
    'dept'
    
    Managers are set by reference.
    
    >>> dept.setManagers((dept.emp1.UID(), dept.emp2.UID(),))
    >>> managers = d.getManagers()
    >>> [m.id for m in managers]
    ['emp1', 'emp2']
    
    Employees are obtained by containment.
    
    >>> employees = d.getEmployees()
    >>> [m.id for m in employees]
    ['emp1', 'emp2', 'emp3']
    """

def test_igroup():
    """Test the functionality of the IGroup adapter.
    
    >>> from Products.membrane.interfaces import IGroup
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept')
    >>> dept = self.portal.dept
    
    >>> id = dept.invokeFactory('Employee', 'emp1')
    >>> id = dept.invokeFactory('Employee', 'emp2')
    >>> id = dept.invokeFactory('Employee', 'emp3')
    
    >>> id = self.portal.invokeFactory('Department', 'dept2')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp4')
    
    Adapt to IGroup.
    
    >>> g = IGroup(dept)
    
    The group title is the content object title.
    
    >>> dept.setTitle('Finance department')
    >>> g.Title()
    'Finance department'
    
    Roles are set on the object.
    
    >>> dept.setRoles(('Reviewer',))
    >>> g.getRoles()
    ('Reviewer',)
    
    The group id is the content object id (global uniqueness is enforced
    separately).
    
    >>> g.getGroupId()
    'dept'
    
    Group members are obtained by containment.
    
    >>> members = list(g.getGroupMembers())
    >>> members.sort()
    >>> members
    ['emp1', 'emp2', 'emp3']
    """

def test_iworkspace():
    """Test the functionality of the IWorkspace adapter.
    
    >>> from Products.borg.interfaces import IWorkspace
    >>> from Products.borg.tests.helpers import FauxUser
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept')
    >>> dept = self.portal.dept
    
    >>> id = dept.invokeFactory('Employee', 'emp1')
    >>> id = dept.invokeFactory('Employee', 'emp2')
    >>> id = dept.invokeFactory('Employee', 'emp3')
    
    >>> id = self.portal.invokeFactory('Department', 'dept2')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp4')
    
    Adapt to IWorkspace.
    
    >>> w = IWorkspace(dept)
    
    Managers are given the 'Manager' local-role.
    
    >>> dept.setManagers((dept.emp1.UID(),))
    >>> w.getLocalRoles()
    {'emp1': ('Manager',)}
    
    Principals can be queried directly.
    
    >>> w.getLocalRolesForPrincipal(FauxUser('emp1'))
    ('Manager',)
    
    Unknown principals get an empty tuple of local roles.
    
    >>> w.getLocalRolesForPrincipal(FauxUser('emp2'))
    ()
    >>> w.getLocalRolesForPrincipal(FauxUser('emp-unknown'))
    ()
    """

def test_validate_id():
    """Verify that the validate_id method checks global uniqueness of group ids.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> id = self.folder.invokeFactory('Department', 'dept2')
    >>> id = self.portal.invokeFactory('Document', 'doc1')
    >>> id = self.portal.invokeFactory('Project', 'proj1')
    >>> dept1 = self.portal.dept1
    
    >>> dept1.validate_id('foo') == None
    True
    
    The current id of the object is always allowed.
    
    >>> dept1.validate_id('dept1') == None
    True
    
    Choosing an id that already exists in the folder or an id for a group
    that already exists results in a validation error. We only test that the
    offending id is mentioned in the error, to avoid being dependent on the
    exact wording of the message.
    
    >>> 'doc1' in dept1.validate_id('doc1')
    True
    
    >>> 'dept2' in dept1.validate_id('dept2')
    True
    
    >>> 'proj1' in dept1.validate_id('proj1')
    True
    
    >>> self.portal.portal_groups.addGroup('group1', (), 'Group one')
    True
    >>> 'group1' in dept1.validate_id('group1')
    True
    
    """
    
def test_department_implies_roles():
    """Verify that a department's roles are given to its members.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp1')
    >>> dept = self.portal.dept1
    
    >>> user = self.portal.portal_membership.getMemberById('emp1')
    >>> 'Reviewer' in user.getRolesInContext(self.portal)
    False
    
    >>> dept.setRoles(('Reviewer',))
    >>> user = self.portal.portal_membership.getMemberById('emp1')
    >>> 'Reviewer' in user.getRolesInContext(self.portal)
    True
    """
    
def test_inactive_department_does_not_imply_roles():
    """If a department is not active, roles should not be given to members.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp1')
    >>> dept = self.portal.dept1
    
    >>> user = self.portal.portal_membership.getMemberById('emp1')
    >>> 'Reviewer' in user.getRolesInContext(self.portal)
    False
    
    >>> dept.setRoles(('Reviewer',))
    >>> self.portal.portal_workflow.doActionFor(dept, 'deactivate')
    >>> user = self.portal.portal_membership.getMemberById('emp1')
    >>> 'Reviewer' in user.getRolesInContext(self.portal)
    False
    """

def test_suite():
    return unittest.TestSuite((
            ZopeDocTestSuite(test_class=BorgTestCase,
                             optionflags=optionflags),
        ))
