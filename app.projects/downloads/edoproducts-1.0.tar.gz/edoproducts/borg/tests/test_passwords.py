import unittest

from zope.testing.doctestunit import DocTestSuite
from utils import configurationSetUp, configurationTearDown, optionflags

def test_passwords_hashed():
    """Check that passwords are hashed
    
    We expect that the password will be saved as a SHA-1 digest.
    
    >>> import sha
    >>> digest = sha.sha('secret').digest()
    
    Set a password.
    
    >>> from Products.borg.content.employee import Employee
    >>> e = Employee('emp')
    >>> e.setPassword('secret')
    
    The value is stored in an annotation, and there is no direct way to
    access it (deliberately). Thus, check the annotation directly.
    
    >>> from zope.app.annotation.interfaces import IAnnotations
    >>> from Products.borg.config import PASSWORD_KEY
    >>> annotations = IAnnotations(e)
    >>> password = annotations[PASSWORD_KEY]
    
    Ensure it is what we expected:
    
    >>> password == digest
    True
    """
    
def test_passwords_not_readable():
    """Ensure that Archetypes does not allow easy access to password digests.
    
    >>> from Products.borg.content.employee import Employee
    >>> e = Employee('emp')
    >>> e.setPassword('secret')
    
    Check that the field accessor gives an error
    
    >>> e.getField('password').get(e)
    ''
    """

def test_confirm_passwords_not_stored():
    """Ensure that Archetypes does not store the confirmation password.
    
    >>> from Products.borg.content.employee import Employee
    >>> e = Employee('emp')
    >>> e.setConfirmPassword('secret')
    
    Check that the field accessor gives an error
    
    >>> e.getField('confirmPassword').get(e)
    ''
    """
    
def test_saving_empty_passwords_do_not_overwrite():
    """Check that if setPassword() is called with an empty string, an existing
    password is not overwritten. This allows the password field to be ignored 
    after initial setting.
    
    >>> from Products.borg.content.employee import Employee
    >>> e = Employee('emp')
    
    Set the initial password and then set an empty one.
    
    >>> e.setPassword('secret')
    >>> e.setPassword('')
    
    Confirm this against the expected hash.
    
    >>> import sha
    >>> digest = sha.sha('secret').digest()
    
    >>> from zope.app.annotation.interfaces import IAnnotations
    >>> from Products.borg.config import PASSWORD_KEY
    >>> annotations = IAnnotations(e)
    >>> password = annotations[PASSWORD_KEY]
    
    >>> password == digest
    True    
    """
    
def test_post_validate_initial():
    """Ensure that post_validate() complains when an initial password is not 
    set.
    
    >>> from Products.borg.content.employee import Employee
    >>> e = Employee('emp')
    
    >>> class FakeRequest(object):
    ...     def __init__(self, **kw):
    ...         self.form = kw
    
    
    >>> errors = {}
    >>> e.post_validate(FakeRequest(password='', confirmPassword=''), errors)
    >>> 'password' in errors
    True
    >>> 'confirmPassword' in errors
    False
    """
    
def test_post_validate_not_initial():
    """Ensure that post_validate() complains when an initial password is not 
    set.
    
    >>> from Products.borg.content.employee import Employee
    >>> e = Employee('emp')
    
    >>> class FakeRequest(object):
    ...     def __init__(self, **kw):
    ...         self.form = kw
    
    >>> errors = {}
    >>> e.setPassword('secret')
    >>> e.post_validate(FakeRequest(password='', confirmPassword=''), errors)
    >>> errors
    {}
    """
    
def test_post_validate_not_match():
    """Ensure that post_validate() complains when passwords do not match.
    
    >>> from Products.borg.content.employee import Employee
    >>> e = Employee('emp')
    
    >>> class FakeRequest(object):
    ...     def __init__(self, **kw):
    ...         self.form = kw
    
    
    >>> errors = {}
    >>> e.setPassword('secret')
    >>> e.post_validate(FakeRequest(password='foo', confirmPassword='bar'), errors)
    >>> 'password' in errors
    True
    >>> 'confirmPassword' in errors
    True
    """

def test_post_validate_match():
    """Ensure that post_validate() complains when passwords do not match.
    
    >>> from Products.borg.content.employee import Employee
    >>> e = Employee('emp')
    
    >>> class FakeRequest(object):
    ...     def __init__(self, **kw):
    ...         self.form = kw
    
    
    >>> errors = {}
    >>> e.post_validate(FakeRequest(password='foo', confirmPassword='foo'), errors)
    >>> 'password' in errors
    False
    >>> 'confirmPassword' in errors
    False
    """

def test_suite():
    return unittest.TestSuite((
            DocTestSuite(setUp=configurationSetUp,
                         tearDown=configurationTearDown,
                         optionflags=optionflags),
        ))