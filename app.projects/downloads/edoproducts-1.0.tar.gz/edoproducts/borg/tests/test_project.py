"""Integration tests for projects.
"""

import unittest
from Testing.ZopeTestCase import ZopeDocTestSuite

from base import BorgTestCase
from utils import optionflags

def test_creation():
    """Test that projects can be created an initiated.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> id = self.portal.invokeFactory('Department', 'dept2')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp2')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp3')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp4')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp5')
    >>> id = self.portal.invokeFactory('Project', 'proj')
    >>> proj = self.portal.proj
    
    Set managers
    
    >>> proj.setManagers((self.portal.dept1.emp1.UID(), self.portal.dept2.emp4.UID()))
    >>> tuple(proj.getManagers())
    (<Employee at ...>, <Employee at ...>)
    
    Set members
    
    >>> proj.setMembers((self.portal.dept1.emp2.UID(), self.portal.dept2.emp5.UID()))
    >>> tuple(proj.getMembers())
    (<Employee at ...>, <Employee at ...>)
    """
    
def test_project_is_group():
    """Verify that that project acts as a group.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Project', 'proj1')
    >>> self.portal.portal_groups.getGroupById('proj1')
    <GroupData at .../proj1 used for ...>
    """

def test_listUsers():
    """Test the listUsers() vocab method.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> id = self.portal.invokeFactory('Department', 'dept2')
    >>> id = self.portal.invokeFactory('Project', 'proj')
    >>> proj = self.portal.proj
    
    Add some employees
    
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp1', title='Emp1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp2', title='Emp2')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp3', title='Emp3')
    
    Check that listUsers returns all of them. Titles are used as names.
    
    >>> values = list(proj.listUsers().values())
    >>> values.sort()
    >>> values
    ['Emp1', 'Emp2', 'Emp3']
    """

def test_iproject():
    """Test the functionality of the IDepartment adapter.
    
    >>> from Products.borg.interfaces import IProject
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> id = self.portal.invokeFactory('Department', 'dept2')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp2')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp3')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp4')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp5')
    >>> id = self.portal.invokeFactory('Project', 'proj')
    >>> proj = self.portal.proj
    
    Now adapt to IProject
    
    >>> p = IProject(proj)
    
    The id should be taken directly from the content object
    
    >>> p.id
    'proj'
    
    Managers are set by reference.
    
    >>> proj.setManagers((self.portal.dept1.emp1.UID(), self.portal.dept2.emp4.UID(),))
    >>> [m.id for m in p.getManagers()]
    ['emp1', 'emp4']
    
    Members are set by reference.
    
    >>> proj.setMembers((self.portal.dept1.emp2.UID(), self.portal.dept2.emp5.UID(),))
    >>> [m.id for m in p.getMembers()]
    ['emp2', 'emp5']
    """
    
def test_igroup():
    """Test the functionality of the IGroup adapter.
    
    >>> from Products.membrane.interfaces import IGroup
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> id = self.portal.invokeFactory('Department', 'dept2')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp2')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp3')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp4')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp5')
    >>> id = self.portal.invokeFactory('Project', 'proj')
    >>> proj = self.portal.proj
    
    Adapt to IGroup.
    
    >>> g = IGroup(proj)
    
    The group title is the content object title.
    
    >>> proj.setTitle('Party Planning')
    >>> g.Title()
    'Party Planning'
    
    Project offer some local roles (via the IWorkspace adapter and a PAS 
    plug-in), but no global roles.
    
    >>> g.getRoles()
    ()
    
    The group id is the content object id (global uniqueness is enforced
    separately).
    
    >>> g.getGroupId()
    'proj'
    
    Group members are obtained by reference - both managers and members are
    included.
    
    >>> proj.setManagers((self.portal.dept1.emp1.UID(), self.portal.dept2.emp4.UID(),))
    >>> proj.setMembers((self.portal.dept1.emp2.UID(), self.portal.dept2.emp5.UID(),))
    >>> members = list(g.getGroupMembers())
    >>> members.sort()
    >>> members
    ['emp1', 'emp2', 'emp4', 'emp5']
    """

def test_iworkspace():
    """Test the functionality of the IWorkspace adapter.
    
    >>> from Products.borg.interfaces import IWorkspace
    >>> from Products.borg.tests.helpers import FauxUser
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> id = self.portal.invokeFactory('Department', 'dept2')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp2')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp3')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp4')
    >>> id = self.portal.dept2.invokeFactory('Employee', 'emp5')
    >>> id = self.portal.invokeFactory('Project', 'proj')
    >>> proj = self.portal.proj
    
    Adapt to IWorkspace.
    
    >>> w = IWorkspace(proj)
    
    Managers are given the 'Manager' local-role.
    
    >>> proj.setManagers((self.portal.dept1.emp1.UID(),))
    >>> w.getLocalRoles()
    {'emp1': ('Manager',)}
    
    Members are given the 'Member' local-role.
    >>> proj.setMembers((self.portal.dept2.emp4.UID(),))
    >>> w.getLocalRoles()
    {...'emp4': ('TeamMember',)...}
    
    Principals can be queried directly.
    
    >>> w.getLocalRolesForPrincipal(FauxUser('emp1'))
    ('Manager',)
    >>> w.getLocalRolesForPrincipal(FauxUser('emp4'))
    ('TeamMember',)
    
    Unknown principals get an empty tuple of local roles.
    
    >>> w.getLocalRolesForPrincipal(FauxUser('emp2'))
    ()
    >>> w.getLocalRolesForPrincipal(FauxUser('emp-unknown'))
    ()
    """

def test_placeful_workflow():
    """Ensure the placeful workflow has been enabled.
    
    >>> from Products.CMFCore.utils import getToolByName
    >>> from Products.borg.config import PLACEFUL_WORKFLOW_POLICY
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Project', 'proj')
    >>> proj = self.portal.proj
    
    >>> placeful_workflow = getToolByName(self.portal, 'portal_placeful_workflow')
    >>> config = placeful_workflow.getWorkflowPolicyConfig(proj)
    >>> config.getPolicyBelowId() == PLACEFUL_WORKFLOW_POLICY
    True
    >>> config.getPolicyInId()
    ''
    """
    
def test_local_roles_for_team_members():
    """Ensure that the TeamMember local role has an actual effect for project
    members, i.e. that they can perform operations reserved for this role.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp2')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp3')
    >>> id = self.portal.invokeFactory('Project', 'proj')
    >>> proj = self.portal.proj
    
    >>> proj.setMembers((self.portal.dept1.emp2.UID(),))
    >>> proj.setManagers((self.portal.dept1.emp3.UID(),))
    
    >>> self.setRoles(('Member',))
    
    >>> from Products.CMFCore.utils import getToolByName
    >>> from Products.CMFCore.permissions import AddPortalContent
    >>> from Products.CMFCore.permissions import ModifyPortalContent
    >>> membership = getToolByName(self.portal, 'portal_membership')
    
    Employee 1 has no special roles - should not be able to add content or 
    modify the project, for example.
    
    >>> self.login('emp1')
    >>> membership.checkPermission(AddPortalContent, proj) == True
    False
    >>> membership.checkPermission(ModifyPortalContent, proj) == True
    False
    
    Employee 2 is a team member, and should be able to add content among other
    things. However, this user cannot perform management tasks.
    
    >>> self.login('emp2')
    >>> membership.checkPermission(AddPortalContent, proj) == True
    True
    >>> membership.checkPermission(ModifyPortalContent, proj) == True
    False
    
    Employee 3 is a manager, and should be able to add content as well as 
    perform management tasks such as modifying the project itself.
    
    >>> self.login('emp3')
    >>> membership.checkPermission(AddPortalContent, proj) == True
    True
    >>> membership.checkPermission(ModifyPortalContent, proj) == True
    True
    """
    
def test_creating_content_as_member():
    """Ensure project members can actually create content.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp1')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp2')
    >>> id = self.portal.dept1.invokeFactory('Employee', 'emp3')
    >>> id = self.portal.invokeFactory('Project', 'proj')
    >>> proj = self.portal.proj
    
    >>> proj.setMembers((self.portal.dept1.emp2.UID(),))
    >>> proj.setManagers((self.portal.dept1.emp3.UID(),))
    
    >>> self.setRoles(('Member',))
    
    When creating a project, the user must set which types will be addable in
    that list. This will default to the list of globally addable types that are
    available to the Owner role. However, this must be set explicitly.
    
    >>> proj.setEnabledContentTypes(proj.defaultEnabledContentTypes())
    
    Now, TeamMembers will have the necessary roles to add these types.
        
    >>> self.login('emp1')
    >>> proj.invokeFactory('Document', 'doc1')
    Traceback (most recent call last):
    ...
    Unauthorized: Cannot create Document
    
    >>> self.login('emp2')
    >>> proj.invokeFactory('Document', 'doc2')
    'doc2'
    
    >>> self.login('emp3')
    >>> proj.invokeFactory('Document', 'doc3')
    'doc3'
    
    Types can later be restricted. Note that managers are not affected so long
    as the Manager role applies.
    
    >>> proj.setEnabledContentTypes(('Image',))
    
    >>> self.login('emp1')
    >>> proj.invokeFactory('Document', 'doc4')
    Traceback (most recent call last):
    ...
    Unauthorized: Cannot create Document
    
    >>> self.login('emp2')
    >>> proj.invokeFactory('Document', 'doc5')
    Traceback (most recent call last):
    ...
    Unauthorized: Cannot create Document
    
    >>> self.login('emp3')
    >>> proj.invokeFactory('Document', 'doc6')
    'doc6'
    """
    
def test_validate_id():
    """Verify that the validate_id method checks global uniqueness of group ids.
    
    >>> self.setRoles(('Manager',))
    >>> id = self.portal.invokeFactory('Project', 'proj1')
    >>> id = self.folder.invokeFactory('Project', 'proj2')
    >>> id = self.portal.invokeFactory('Document', 'doc1')
    >>> id = self.portal.invokeFactory('Department', 'dept1')
    >>> proj1 = self.portal.proj1
    
    >>> proj1.validate_id('foo') == None
    True
    
    The current id of the object is always allowed.
    
    >>> proj1.validate_id('proj1') == None
    True
    
    Choosing an id that already exists in the folder or an id for a group
    that already exists results in a validation error. We only test that the
    offending id is mentioned in the error, to avoid being dependent on the
    exact wording of the message.
    
    >>> 'doc1' in proj1.validate_id('doc1')
    True
    
    >>> 'proj2' in proj1.validate_id('proj2')
    True
    
    >>> 'dept1' in proj1.validate_id('dept1')
    True
    
    >>> self.portal.portal_groups.addGroup('group1', (), 'Group one')
    True
    >>> 'group1' in proj1.validate_id('group1')
    True
    """

def test_suite():
    return unittest.TestSuite((
            ZopeDocTestSuite(test_class=BorgTestCase,
                             optionflags=optionflags),
        ))
