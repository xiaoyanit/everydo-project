import unittest
from Testing.ZopeTestCase import ZopeDocTestSuite

from base import BorgTestCase
from utils import optionflags

def test_suite():
    return unittest.TestSuite((
            ZopeDocTestSuite('Products.borg.content.schema',
                             test_class=BorgTestCase,
                             optionflags=optionflags),
        ))