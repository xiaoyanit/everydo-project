"""Integration tests for functionality around determining addable types.
"""

import unittest
from Testing.ZopeTestCase import ZopeDocTestSuite

from base import BorgTestCase
from utils import optionflags

def test_getFactoryPermission():
    """Test the utility method getFactoryPermisssion()
    
    >>> from Products.borg.content.utils import getFactoryPermission
    >>> t = self.portal.portal_types
    
    >>> getFactoryPermission(self.folder, t['Document'])
    'ATContentTypes: Add Document'
    
    >>> getFactoryPermission(self.folder, t['Discussion Item']) == None
    True
    """
    
def test_enableAddingTypes(self):
    """Test the utility method enableAddingTypes()
    
    >>> from Products.borg.content.utils import enableAddingTypes
    >>> from Products.borg.content.utils import getFactoryPermission
    
    >>> def rolesOf(context, permission):
    ...     return [r['name'] for r in context.rolesOfPermission(permission) if r['selected']]
    
    >>> t = self.portal.portal_types
    >>> allTypes = (t['Document'], t['Image'], t['News Item'])
    
    >>> documentPermission = getFactoryPermission(self.folder, t['Document'])
    >>> 'Reviewer' in rolesOf(self.folder, documentPermission)
    False
    
    >>> enableAddingTypes(self.folder, allTypes, ('Document',), 'Reviewer')
    >>> 'Reviewer' in rolesOf(self.folder, documentPermission)
    True
    
    >>> enableAddingTypes(self.folder, allTypes, ('Image',), 'Reviewer')
    >>> 'Reviewer' in rolesOf(self.folder, documentPermission)
    False
    
    """

def test_addableTypesProvider(self):
    """Test the listing of addable types and default-addable types
    
    >>> from Products.borg.interfaces import IAddableTypesProvider
    >>> provider = IAddableTypesProvider(self.folder)
    
    The availableTypes property lists all globally addable types.
    
    >>> t = self.portal.portal_types
    
    >>> t['Document'].global_allow = False
    >>> t['Document'] in provider.availableTypes
    False
    
    >>> t['Document'].global_allow = True
    >>> t['Document'] in provider.availableTypes
    True
    
    The defaultAddableTypes property lists those types in availableTypes that
    are also addable as Owner in the given context.
    
    >>> from Products.borg.content.utils import getFactoryPermission
    >>> permission = getFactoryPermission(self.folder, t['Document'])
    
    >>> t['Document'] in provider.defaultAddableTypes
    True
    
    >>> self.folder.manage_permission(permission, ('Manager',), False)
    >>> t['Document'] in provider.defaultAddableTypes
    False
    """

def test_suite():
    return unittest.TestSuite((
            ZopeDocTestSuite(test_class=BorgTestCase,
                             optionflags=optionflags),
        ))
