from zope.interface import Interface, Attribute

# XXX: This belongs in a more general package (possibly Archetypes itself)
#  - consider options for integrating with whitmo-schema-by-interface branch
#  - if this moves, also move content/schema.py and tests/test_setup.py

class ISchemaInvalidatedEvent(Interface):
    """An event fired when the schema of a content object is to be invalidated
    (because it has changed).
    """
    
    klass = Attribute("The class object of the content object being invalidated")

class IExtensibleSchemaProvider(Interface):
    """An Archetypes object that supports extensible schemas.
    
    The Schema() method is really part of IBaseObject from Archetypes. 
    Implementations of IExtensibleSchema provider ensures that this is
    dynamic, using an ISchemaExtender to extend the basic schema of a a content
    type.
    """
    
    def Schema():
        """Return the schema to be used.
        
        Note that schemas may be cached. 
        """

class ISchemaExtender(Interface):
    """Extension mechanism for Archetypes schemas.
    
    By registering adapters from a given content type (e.g. IEmployeeContent)
    to ISchemaExtender, third party products can add new fields to the schema
    of the object.
    
    Note that the extended schema may be cached. If you need the schema 
    extension to happen again (e.g. because you registered a new local adapter
    to override the existing behaviour) you must either re-start Zope, or
    fire an ISchemaInvalidatedEvent event.
    """
    
    def extend(schema):
        """Return an Archetypes schema that is an extension of the given
        schema.
        
        Ordinarily, fields should not be removed from the given schema.
        """