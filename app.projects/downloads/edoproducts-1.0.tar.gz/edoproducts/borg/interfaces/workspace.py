from zope.interface import Interface

# XXX: This belongs in a more re-usable package
# Both 'teamspace' and 'borg' could use this

class IWorkspace(Interface):
    """A workspace.
    
    A workspace gives information to the Pluggable Authentication Service about 
    local roles.
    """
    
    def getLocalRolesForPrincipal(principal):
        """Return a sequence of all local roles for a principal.
        """

    def getLocalRoles():
        """Return a dictonary mapping principals to their roles within
        a workspace.
        """
