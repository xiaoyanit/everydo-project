from zope.interface import Interface, Attribute
from zope import schema

class IEmployeeContent(Interface):
    """Marker interface for employee content objects"""
    
class IEmployee(Interface):
    """An employee, which is also a user.
    """
    
    id = schema.TextLine(title=u'Identifier',
                         description=u'An identifier for the employee',
                         required=True,
                         readonly=True)
    
    fullname = schema.TextLine(title=u'Full name',
                               description=u"The employee's full name for display purposes",
                               required=True,
                               readonly=True)
                               
class IEmployeeModifiedEvent(Interface):
    """An event fired when an employee object is saved.
    """
    
    context = Attribute("The content object that was saved.")