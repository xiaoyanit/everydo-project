from zope.interface import Interface
from zope import schema

class IProjectContent(Interface):
    """Marker interface for project content objects"""

class IProject(Interface):
    """A project, which may also act as a group
    """
    
    id = schema.TextLine(title=u'Identifier',
                         description=u'An identifier for the project',
                         required=True,
                         readonly=True)
    
    def getManagers():
        """Get the manager IEmployee's of this project.
        
        Managers may have special privileges.
        """
    
    def getMembers():
        """Get a list of IEmployee's that are members of this project.
        """
        
class ILocalWorkflowSelection(Interface):
    """A selection of a local workflow for projects.
    
    This will normally be looked up as a utility.
    """
    
    workflowPolicy = schema.TextLine(title=u'Workflow policy identifier',
                                    description=u'The id of the placeful workflow policy to use',
                                    required=True,
                                    readonly=True)