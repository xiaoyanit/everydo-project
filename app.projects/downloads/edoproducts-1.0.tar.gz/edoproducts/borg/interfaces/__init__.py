"""Interfaces used by b-org
"""

from department import IDepartmentContent
from department import IDepartment

from employee import IEmployeeContent
from employee import IEmployee
from employee import IEmployeeModifiedEvent

from project import IProjectContent
from project import IProject
from project import ILocalWorkflowSelection

from workspace import IWorkspace

from schema import ISchemaInvalidatedEvent
from schema import IExtensibleSchemaProvider
from schema import ISchemaExtender

from utils import IEmployeeLocator
from utils import IAddableTypesProvider
from utils import IValidRolesProvider