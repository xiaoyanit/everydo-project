from zope.interface import Interface, Attribute
from zope import schema

from Products.CMFCore.interfaces import ITypeInformation

from employee import IEmployee

class IEmployeeLocator(Interface):
    """A component capable of finding all available employees in the portal.
    """

    employees = Attribute(u'A list of tuples (uid, name) of employees')

class IAddableTypesProvider(Interface):
    """A component capable of finding addable types in a given context.
    """

    availableTypes = schema.Tuple(title=u'Available types',
                                  description=u'A list of all addable types',
                                  value_type=schema.Object(ITypeInformation))

    defaultAddableTypes = schema.Tuple(title=u'Default addable types',
                                       description=u'A list of types to be addable by default',
                                       value_type=schema.Object(ITypeInformation))

class IValidRolesProvider(Interface):
    """A component capable of finding valid roles in a given context.
    """

    availableRoles = schema.Tuple(title=u'Available roles',
                                  description=u'A list of valid roles',
                                  value_type=schema.TextLine())