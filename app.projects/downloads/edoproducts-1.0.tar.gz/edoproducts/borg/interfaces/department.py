from zope.interface import Interface
from zope import schema

class IDepartmentContent(Interface):
    """Marker interface for department content objects"""

class IDepartment(Interface):
    """A department, which may contain employees. 
    
    Departments can also act as groups.
    """
    
    id = schema.TextLine(title=u'Identifier',
                         description=u'An identifier for the department',
                         required=True,
                         readonly=True)

    def getManagers():
        """Get the manager IEmployee's of this department.
        
        Managers may have special privileges.
        """
    
    def getEmployees():
        """Get a list of IEmployee's in this department.
        """